# Web Vulnerability Scanner (WebVulnHunter v1.0)

A comprehensive web vulnerability scanner with multiple interfaces, capable of detecting 10+ types of web vulnerabilities and enhanced with AI capabilities.

## Features

- Three different interfaces:
  - Web Interface (Flask web application)
  - Command Line Interface (CLI)
  - Graphical User Interface (GUI)
- Detect 10+ types of vulnerabilities including:
  - Cross-Site Scripting (XSS)
  - SQL Injection
  - Cross-Site Request Forgery (CSRF)
  - Insecure Headers
  - Local File Inclusion (LFI)
  - Server-Side Request Forgery (SSRF)
  - Open Redirects
  - XML External Entity (XXE)
  - Sensitive Information Disclosure
- AI-enhanced detection using machine learning
- Authenticated scanning capability
- Detailed vulnerability reports

## Installation

1. Extract the archive:
   ```
   tar -xzvf WebVulnHunter_v1.0.tar.gz
   cd WebVulnHunter_v1.0
   ```

2. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Create an admin user:
   ```
   python create_admin.py
   ```

## Usage

### Web Interface

Start the web server:

```
python -m gunicorn --bind 0.0.0.0:5000 main:app
```

Then open a browser and navigate to `http://localhost:5000`. Log in with username `admin` and password `admin123`.

### Command Line Interface (CLI)

You can use the CLI in two ways:

1. Using the scan.py wrapper:
   ```
   python scan.py --url https://example.com
   ```

2. Directly with modules:
   ```
   python -m interfaces.cli --url https://example.com
   ```

#### CLI Options

- `--url URL`: Target URL to scan (required)
- `--threads N`: Number of concurrent threads (default: 5)
- `--depth N`: Crawl depth (default: 3)
- `--verbose`: Enable verbose output
- `--output FILE`: Output report file path
- `--username USER`: Username for authenticated scan
- `--password PASS`: Password for authenticated scan
- `--login-url URL`: Login URL for authenticated scan
- `--format {txt,json,html}`: Output format (default: txt)

### Graphical User Interface (GUI)

For systems with a graphical environment:

```
python -m interfaces.gui
```

## Configuration

Configuration settings are stored in `config.json`. You can modify this file to:
- Adjust scanning parameters
- Add custom payloads for different vulnerability types
- Set request timeouts and delays
- Configure exclusion patterns

## Contributing

If you'd like to contribute to this project, please follow these steps:
1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Commit your changes: `git commit -am 'Add new feature'`
4. Push to the branch: `git push origin feature-name`
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.