#!/usr/bin/env python3
"""
Web Vulnerability Scanner - Command Line Wrapper
This script provides a simple way to run the vulnerability scanner from the command line.
"""

import asyncio
import sys
from interfaces.cli import cli_scan, parse_args

if __name__ == "__main__":
    args = parse_args()
    
    try:
        # Run the scan
        asyncio.run(cli_scan(args))
    except KeyboardInterrupt:
        print("\nScan interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)