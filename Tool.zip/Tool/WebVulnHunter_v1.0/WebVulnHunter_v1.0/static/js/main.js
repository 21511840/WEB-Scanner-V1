/**
 * Web Vulnerability Scanner - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Toggle advanced scan options
    const advancedOptionsToggle = document.getElementById('advanced-options-toggle');
    if (advancedOptionsToggle) {
        advancedOptionsToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const scanOptions = document.querySelector('.scan-options');
            if (scanOptions) {
                scanOptions.style.display = scanOptions.style.display === 'none' ? 'block' : 'none';
                advancedOptionsToggle.textContent = scanOptions.style.display === 'none' ? 'Show Advanced Options' : 'Hide Advanced Options';
            }
        });
    }

    // Toggle vulnerability details
    const vulnerabilityToggles = document.querySelectorAll('.vulnerability-toggle');
    vulnerabilityToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            const detailsId = this.getAttribute('data-target');
            const details = document.getElementById(detailsId);
            if (details) {
                details.style.display = details.style.display === 'none' ? 'block' : 'none';
                this.textContent = details.style.display === 'none' ? 'Show Details' : 'Hide Details';
            }
        });
    });

    // Handle login/register tab switching
    const loginTab = document.getElementById('login-tab');
    const registerTab = document.getElementById('register-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    if (loginTab && registerTab) {
        loginTab.addEventListener('click', function(e) {
            e.preventDefault();
            loginTab.classList.add('active');
            registerTab.classList.remove('active');
            loginForm.style.display = 'block';
            registerForm.style.display = 'none';
        });

        registerTab.addEventListener('click', function(e) {
            e.preventDefault();
            registerTab.classList.add('active');
            loginTab.classList.remove('active');
            registerForm.style.display = 'block';
            loginForm.style.display = 'none';
        });
    }

    // Handle scan status updates
    function updateScanStatus() {
        const scanStatusElements = document.querySelectorAll('.scan-status-updater');
        
        scanStatusElements.forEach(element => {
            const scanId = element.getAttribute('data-scan-id');
            const statusElement = element.querySelector('.scan-status');
            const progressBar = element.querySelector('.progress-bar');
            
            if (scanId && statusElement && progressBar) {
                fetch(`/scan/${scanId}/status`)
                    .then(response => response.json())
                    .then(data => {
                        // Update status text
                        statusElement.textContent = data.status;
                        statusElement.className = 'scan-status status-' + data.status;
                        
                        // Update progress bar
                        progressBar.style.width = data.progress + '%';
                        progressBar.setAttribute('aria-valuenow', data.progress);
                        
                        // If completed, add a link to view the report
                        if (data.status === 'completed' && !element.querySelector('.view-report-btn')) {
                            const viewReportBtn = document.createElement('a');
                            viewReportBtn.href = `/scan/${scanId}`;
                            viewReportBtn.className = 'btn btn-sm btn-primary view-report-btn ms-2';
                            viewReportBtn.textContent = 'View Report';
                            statusElement.parentNode.appendChild(viewReportBtn);
                            
                            // Stop polling for this scan
                            return;
                        }
                        
                        // If failed, stop polling
                        if (data.status === 'failed') {
                            return;
                        }
                        
                        // Continue polling if in progress
                        if (data.status === 'in_progress') {
                            setTimeout(() => updateScanStatus(), 5000);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating scan status:', error);
                    });
            }
        });
    }

    // Start polling for scan status updates if there are any ongoing scans
    if (document.querySelectorAll('.scan-status-updater').length > 0) {
        updateScanStatus();
    }

    // Handle export report buttons
    const exportButtons = document.querySelectorAll('.export-report-btn');
    exportButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const scanId = this.getAttribute('data-scan-id');
            const format = this.getAttribute('data-format');
            
            // Show loading spinner
            const exportStatus = document.getElementById('export-status');
            if (exportStatus) {
                exportStatus.innerHTML = '<div class="loader"></div><p>Generating report...</p>';
            }
            
            // Request export
            fetch(`/scan/${scanId}/export/${format}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Create download link
                        const downloadLink = document.createElement('a');
                        downloadLink.href = data.download_url;
                        downloadLink.className = 'btn btn-success';
                        downloadLink.textContent = 'Download Report';
                        
                        // Update status
                        if (exportStatus) {
                            exportStatus.innerHTML = '<p>Report generated successfully!</p>';
                            exportStatus.appendChild(downloadLink);
                        }
                    } else {
                        // Show error
                        if (exportStatus) {
                            exportStatus.innerHTML = '<p class="text-danger">Error generating report: ' + data.error + '</p>';
                        }
                    }
                })
                .catch(error => {
                    console.error('Error exporting report:', error);
                    if (exportStatus) {
                        exportStatus.innerHTML = '<p class="text-danger">Error generating report. Please try again.</p>';
                    }
                });
        });
    });

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('.delete-confirm');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Chart initialization for vulnerability statistics if Chart.js is loaded
    const statsCanvas = document.getElementById('vulnerability-stats-chart');
    if (typeof Chart !== 'undefined' && statsCanvas) {
        const ctx = statsCanvas.getContext('2d');
        
        // Get data from data attributes
        const critical = parseInt(statsCanvas.getAttribute('data-critical') || 0);
        const high = parseInt(statsCanvas.getAttribute('data-high') || 0);
        const medium = parseInt(statsCanvas.getAttribute('data-medium') || 0);
        const low = parseInt(statsCanvas.getAttribute('data-low') || 0);
        const info = parseInt(statsCanvas.getAttribute('data-info') || 0);
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Critical', 'High', 'Medium', 'Low', 'Info'],
                datasets: [{
                    data: [critical, high, medium, low, info],
                    backgroundColor: [
                        '#dc3545', // Critical - Red
                        '#fd7e14', // High - Orange
                        '#ffc107', // Medium - Yellow
                        '#20c997', // Low - Green
                        '#17a2b8'  // Info - Blue
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'right'
                }
            }
        });
    }
});
