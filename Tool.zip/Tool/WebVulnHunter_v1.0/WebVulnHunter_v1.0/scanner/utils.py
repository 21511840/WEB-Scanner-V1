import re
import logging
from urllib.parse import urlparse, urljoin, urlsplit
from datetime import datetime

logger = logging.getLogger(__name__)

def url_normalize(url):
    """
    Normalize a URL by ensuring it has a scheme
    
    Args:
        url: URL to normalize
        
    Returns:
        str: Normalized URL
    """
    if not url:
        return ""
    
    if not re.match(r'http(s?):', url):
        url = 'http://' + url
    
    return url

def get_domain(url):
    """
    Extract domain from URL
    
    Args:
        url: URL to extract domain from
        
    Returns:
        str: Domain name
    """
    parsed = urlparse(url_normalize(url))
    domain = parsed.netloc
    
    # Remove www. prefix if present
    if domain.startswith('www.'):
        domain = domain[4:]
    
    return domain

def is_same_domain(url1, url2):
    """
    Check if two URLs belong to the same domain
    
    Args:
        url1: First URL
        url2: Second URL
        
    Returns:
        bool: True if same domain, False otherwise
    """
    return get_domain(url1) == get_domain(url2)

def display_time(seconds, granularity=3):
    """
    Format time in a human-readable format
    
    Args:
        seconds: Time in seconds
        granularity: Number of time units to show
        
    Returns:
        str: Formatted time string
    """
    intervals = (
        ('h', 3600),
        ('m', 60),
        ('s', 1),
    )
    
    result = []
    seconds = int(seconds) + 1
    
    for name, count in intervals:
        value = seconds // count
        if value:
            seconds -= value * count
            result.append(f"{value}{name}")
    
    return ' '.join(result[:granularity])

def severity_to_int(severity):
    """
    Convert severity string to integer for sorting
    
    Args:
        severity: Severity string (Critical, High, Medium, Low, Info)
        
    Returns:
        int: Severity as integer (5 = Critical, 1 = Info)
    """
    severity_map = {
        "Critical": 5,
        "High": 4,
        "Medium": 3,
        "Low": 2,
        "Info": 1
    }
    
    return severity_map.get(severity, 0)

def get_timestamp():
    """
    Get current timestamp in a format suitable for filenames
    
    Returns:
        str: Formatted timestamp
    """
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def sort_vulnerabilities(vulnerabilities):
    """
    Sort vulnerabilities by severity (most severe first)
    
    Args:
        vulnerabilities: List of vulnerability dictionaries
        
    Returns:
        list: Sorted vulnerabilities
    """
    return sorted(
        vulnerabilities,
        key=lambda x: severity_to_int(x.get('severity', 'Low')),
        reverse=True
    )

def group_vulnerabilities_by_type(vulnerabilities):
    """
    Group vulnerabilities by type
    
    Args:
        vulnerabilities: List of vulnerability dictionaries
        
    Returns:
        dict: Vulnerabilities grouped by type
    """
    grouped = {}
    
    for vuln in vulnerabilities:
        vuln_type = vuln.get('type', 'Unknown')
        if vuln_type not in grouped:
            grouped[vuln_type] = []
        
        grouped[vuln_type].append(vuln)
    
    return grouped

def get_vulnerability_stats(vulnerabilities):
    """
    Get vulnerability statistics
    
    Args:
        vulnerabilities: List of vulnerability dictionaries
        
    Returns:
        dict: Vulnerability statistics
    """
    stats = {
        'total': len(vulnerabilities),
        'by_severity': {
            'Critical': 0,
            'High': 0,
            'Medium': 0,
            'Low': 0,
            'Info': 0
        },
        'by_type': {}
    }
    
    for vuln in vulnerabilities:
        severity = vuln.get('severity', 'Low')
        vuln_type = vuln.get('type', 'Unknown')
        
        # Count by severity
        if severity in stats['by_severity']:
            stats['by_severity'][severity] += 1
        
        # Count by type
        if vuln_type not in stats['by_type']:
            stats['by_type'][vuln_type] = 0
        stats['by_type'][vuln_type] += 1
    
    return stats
