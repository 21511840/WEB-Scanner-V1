import logging
import re
import asyncio
from urllib.parse import parse_qs, urlparse, urlencode, urljoin
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class VulnerabilityChecks:
    """
    Class to perform various vulnerability checks on web applications
    """
    def __init__(self, session_manager, config):
        """
        Initialize with session manager and config
        
        Args:
            session_manager: Session manager for HTTP requests
            config: Configuration dictionary
        """
        self.session_manager = session_manager
        self.config = config
    
    async def check_security_headers(self, url, headers=None):
        """
        Check if the website has proper security headers
        
        Args:
            url: URL to check
            headers: Optional headers dict if already retrieved
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        try:
            if headers is None:
                response = await self.session_manager.get(url)
                headers = response.headers
            
            headers_to_check = self.config.get("headers_to_check", {
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": ["DENY", "SAMEORIGIN"],
                "Content-Security-Policy": None,
                "Strict-Transport-Security": "max-age=",
                "X-XSS-Protection": "1; mode=block"
            })
            
            for header, expected in headers_to_check.items():
                if header not in headers:
                    # Get full request and response data
                    request_info = {
                        "method": "GET",
                        "url": url,
                        "headers": self.session_manager.session.headers if self.session_manager.session else {}
                    }
                    
                    response_info = {
                        "status": response.status if hasattr(response, 'status') else 'Unknown',
                        "headers": dict(headers),
                        "body": "Response body too large to include"
                    }
                    
                    vulnerabilities.append({
                        "severity": "Medium",
                        "type": "Headers",
                        "url": url,
                        "message": f"Missing {header} header",
                        "details": {
                            "parameter": "HTTP Headers",
                            "payload": f"Expected header: {header}",
                            "request": str(request_info),
                            "response": str(response_info)
                        }
                    })
                elif expected:
                    if isinstance(expected, list):
                        if headers[header] not in expected:
                            vulnerabilities.append({
                                "severity": "Low",
                                "type": "Headers",
                                "url": url,
                                "message": f"Weak {header} value: '{headers[header]}'"
                            })
                    elif isinstance(expected, str) and expected not in headers[header]:
                        vulnerabilities.append({
                            "severity": "Low",
                            "type": "Headers",
                            "url": url,
                            "message": f"Weak {header} value: '{headers[header]}'"
                        })
        
        except Exception as e:
            logger.error(f"Error checking headers for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"Headers Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_csrf(self, url):
        """
        Check for CSRF vulnerabilities in forms
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        try:
            response = await self.session_manager.get(url)
            soup = BeautifulSoup(await response.text(), 'html.parser')
            forms = soup.find_all('form')
            
            for form in forms:
                inputs = form.find_all('input')
                csrf_fields = self.config.get("csrf_fields", ["csrf_token", "csrf"])
                
                has_csrf = any(input_tag.get('name', '').lower() in csrf_fields for input_tag in inputs)
                
                if not has_csrf:
                    method = form.get('method', 'get').lower()
                    action = urljoin(url, form.get('action', ''))
                    
                    # Get form details
                    form_inputs = []
                    for input_tag in form.find_all('input'):
                        form_inputs.append({
                            'name': input_tag.get('name', ''),
                            'type': input_tag.get('type', ''),
                            'value': input_tag.get('value', '')
                        })
                    
                    # Get full request and response data
                    request_info = {
                        "method": "GET",
                        "url": url,
                        "headers": self.session_manager.session.headers if self.session_manager.session else {}
                    }
                    
                    response_info = {
                        "status": response.status if hasattr(response, 'status') else 'Unknown',
                        "headers": dict(response.headers) if hasattr(response, 'headers') else {},
                        "form_details": form_inputs
                    }
                    
                    vulnerabilities.append({
                        "severity": "High",
                        "type": "CSRF",
                        "url": url,
                        "message": f"Missing CSRF Token in {method.upper()} form (action: {action})",
                        "details": {
                            "parameter": "Form Submission",
                            "payload": f"A malicious form could be submitted without CSRF protection",
                            "request": str(request_info),
                            "response": str(response_info),
                            "form_action": action,
                            "form_method": method
                        }
                    })
                elif not any(input_tag.get('type') == 'hidden' for input_tag in inputs if input_tag.get('name', '').lower() in csrf_fields):
                    vulnerabilities.append({
                        "severity": "Medium",
                        "type": "CSRF",
                        "url": url,
                        "message": f"Weak CSRF implementation (non-hidden token)"
                    })
        
        except Exception as e:
            logger.error(f"Error checking CSRF for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"CSRF Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_xss(self, url):
        """
        Check for XSS vulnerabilities by injecting XSS payloads
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        parsed_url = urlparse(url)
        params = parse_qs(parsed_url.query)
        
        if not params:
            return vulnerabilities
        
        try:
            xss_payloads = self.config.get("xss_payloads", ["<script>alert('xss')</script>"])
            
            for param in params:
                for payload in xss_payloads:
                    # Create a new set of parameters with the XSS payload
                    new_params = params.copy()
                    new_params[param] = [payload]
                    query_string = urlencode(new_params, doseq=True)
                    
                    # Create test URL
                    test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}?{query_string}"
                    
                    # Send request with payload
                    response = await self.session_manager.get(test_url)
                    response_text = await response.text()
                    
                    # Check if the payload is reflected without encoding/escaping
                    if payload in response_text:
                        vulnerabilities.append({
                            "severity": "High",
                            "type": "XSS",
                            "url": url,
                            "message": f"Potential XSS in parameter '{param}' with payload '{payload}'",
                            "details": {
                                "param": param,
                                "payload": payload,
                                "test_url": test_url
                            }
                        })
                        # Break after finding the first vulnerability for this parameter
                        break
        
        except Exception as e:
            logger.error(f"Error checking XSS for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"XSS Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_sql_injection(self, url):
        """
        Check for SQL injection vulnerabilities
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        parsed_url = urlparse(url)
        params = parse_qs(parsed_url.query)
        
        if not params:
            return vulnerabilities
        
        try:
            sql_payloads = self.config.get("sql_payloads", ["' OR 1=1 --"])
            sql_error_patterns = [
                "SQL syntax",
                "mysql_fetch",
                "ORA-",
                "Oracle Error",
                "PostgreSQL",
                "SQLite3::",
                "Unclosed quotation mark",
                "OLEDB",
                "MSSQL",
                "mysql_",
                "syntax error"
            ]
            
            for param in params:
                for payload in sql_payloads:
                    # Create a new set of parameters with the SQL injection payload
                    new_params = params.copy()
                    new_params[param] = [payload]
                    query_string = urlencode(new_params, doseq=True)
                    
                    # Create test URL
                    test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}?{query_string}"
                    
                    # Send request with payload
                    response = await self.session_manager.get(test_url)
                    response_text = await response.text()
                    
                    # Check for SQL error patterns in the response
                    for pattern in sql_error_patterns:
                        if pattern.lower() in response_text.lower():
                            vulnerabilities.append({
                                "severity": "High",
                                "type": "SQL Injection",
                                "url": url,
                                "message": f"Potential SQL Injection in parameter '{param}' with payload '{payload}'",
                                "details": {
                                    "param": param,
                                    "payload": payload,
                                    "test_url": test_url,
                                    "error_pattern": pattern
                                }
                            })
                            # Break after finding the first vulnerability for this parameter
                            break
        
        except Exception as e:
            logger.error(f"Error checking SQL Injection for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"SQL Injection Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_open_redirect(self, url):
        """
        Check for Open Redirect vulnerabilities
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        parsed_url = urlparse(url)
        params = parse_qs(parsed_url.query)
        
        # Look for parameters that might be used for redirection
        redirect_params = [param for param in params if any(rp in param.lower() for rp in [
            'redirect', 'url', 'return', 'next', 'redir', 'goto', 'destination', 'continue'
        ])]
        
        if not redirect_params:
            return vulnerabilities
        
        try:
            redirect_payloads = self.config.get("open_redirect_payloads", ["//evil.com", "https://evil.com/"])
            
            for param in redirect_params:
                for payload in redirect_payloads:
                    # Create a new set of parameters with the redirect payload
                    new_params = params.copy()
                    new_params[param] = [payload]
                    query_string = urlencode(new_params, doseq=True)
                    
                    # Create test URL
                    test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}?{query_string}"
                    
                    # Send request with payload
                    response = await self.session_manager.get(test_url, allow_redirects=False)
                    
                    # Check for redirect to the malicious domain
                    if response.status in (301, 302, 303, 307, 308):
                        location = response.headers.get('Location', '')
                        if 'evil.com' in location:
                            vulnerabilities.append({
                                "severity": "Medium",
                                "type": "Open Redirect",
                                "url": url,
                                "message": f"Open Redirect in parameter '{param}' redirecting to '{location}'",
                                "details": {
                                    "param": param,
                                    "payload": payload,
                                    "test_url": test_url,
                                    "redirect_location": location
                                }
                            })
                            # Break after finding the first vulnerability for this parameter
                            break
        
        except Exception as e:
            logger.error(f"Error checking Open Redirect for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"Open Redirect Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_lfi(self, url):
        """
        Check for Local File Inclusion vulnerabilities
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        parsed_url = urlparse(url)
        params = parse_qs(parsed_url.query)
        
        if not params:
            return vulnerabilities
        
        try:
            lfi_payloads = self.config.get("lfi_payloads", ["../../../etc/passwd"])
            lfi_patterns = [
                "root:x:",
                "nobody:x:",
                "bin:x:",
                "[drivers]",
                "boot.ini",
                "[boot loader]"
            ]
            
            for param in params:
                for payload in lfi_payloads:
                    # Create a new set of parameters with the LFI payload
                    new_params = params.copy()
                    new_params[param] = [payload]
                    query_string = urlencode(new_params, doseq=True)
                    
                    # Create test URL
                    test_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}?{query_string}"
                    
                    # Send request with payload
                    response = await self.session_manager.get(test_url)
                    response_text = await response.text()
                    
                    # Check for LFI patterns in the response
                    for pattern in lfi_patterns:
                        if pattern in response_text:
                            vulnerabilities.append({
                                "severity": "High",
                                "type": "LFI",
                                "url": url,
                                "message": f"Potential Local File Inclusion in parameter '{param}' with payload '{payload}'",
                                "details": {
                                    "param": param,
                                    "payload": payload,
                                    "test_url": test_url,
                                    "pattern": pattern
                                }
                            })
                            # Break after finding the first vulnerability for this parameter
                            break
        
        except Exception as e:
            logger.error(f"Error checking LFI for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"LFI Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_information_disclosure(self, url):
        """
        Check for information disclosure vulnerabilities
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        
        try:
            response = await self.session_manager.get(url)
            response_text = await response.text()
            
            # Get sensitive patterns from config
            sensitive_patterns = self.config.get("sensitive_patterns", [
                ["api_key", "Potential API key leakage"],
                ["password", "Potential password leakage"]
            ])
            
            # Check for each pattern
            for pattern, description in sensitive_patterns:
                regex = re.compile(r'["\']?\b{0}["\']?\s*[:=]\s*["\']?([^"\'<>\s]+)["\']?'.format(pattern), re.IGNORECASE)
                matches = regex.findall(response_text)
                
                if matches:
                    context = []
                    for match in matches:
                        # Try to find some context around the match
                        idx = response_text.find(match)
                        if idx >= 0:
                            start = max(0, idx - 30)
                            end = min(len(response_text), idx + len(match) + 30)
                            context.append(f"...{response_text[start:end]}...")
                    
                    vulnerabilities.append({
                        "severity": "Medium",
                        "type": "Sensitive Data",
                        "url": url,
                        "message": f"{description} (found {len(matches)} instances)",
                        "details": {
                            "pattern": pattern,
                            "count": len(matches),
                            "context": context[:3]  # Limit to 3 examples
                        }
                    })
        
        except Exception as e:
            logger.error(f"Error checking Information Disclosure for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"Information Disclosure Check Failed: {str(e)}"
            })
        
        return vulnerabilities
    
    async def check_forms(self, url):
        """
        Check for vulnerabilities in forms
        
        Args:
            url: URL to check
            
        Returns:
            list: Vulnerabilities found
        """
        vulnerabilities = []
        
        try:
            response = await self.session_manager.get(url)
            soup = BeautifulSoup(await response.text(), 'html.parser')
            forms = soup.find_all('form')
            
            for form in forms:
                # Check for insecure methods
                method = form.get('method', 'get').lower()
                if method == 'get' and any(input_tag.get('type') == 'password' for input_tag in form.find_all('input')):
                    vulnerabilities.append({
                        "severity": "Medium",
                        "type": "Insecure Form",
                        "url": url,
                        "message": "Password field in a GET form method"
                    })
                
                # Check for unencrypted password fields
                action = urljoin(url, form.get('action', ''))
                if action.startswith('http:') and any(input_tag.get('type') == 'password' for input_tag in form.find_all('input')):
                    vulnerabilities.append({
                        "severity": "High",
                        "type": "Insecure Form",
                        "url": url,
                        "message": "Password field submitted over unencrypted HTTP"
                    })
                
                # Check for autocomplete on sensitive fields
                for input_tag in form.find_all('input', {'type': 'password'}):
                    if input_tag.get('autocomplete') != 'off':
                        vulnerabilities.append({
                            "severity": "Low",
                            "type": "Insecure Form",
                            "url": url,
                            "message": "Password field does not have autocomplete disabled"
                        })
        
        except Exception as e:
            logger.error(f"Error checking forms for {url}: {str(e)}")
            vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"Form Check Failed: {str(e)}"
            })
        
        return vulnerabilities
