"""
Scanner package for web vulnerability scanning.
This package contains all the scanning logic.
"""
from scanner.core import VulnerabilityScanner

__all__ = ['VulnerabilityScanner']
