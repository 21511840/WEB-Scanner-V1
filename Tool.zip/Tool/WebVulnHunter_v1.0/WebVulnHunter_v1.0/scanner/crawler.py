import logging
import asyncio
from urllib.parse import urljoin, urlparse, parse_qs
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class Crawler:
    """
    Web crawler to discover pages on a website
    """
    
    def __init__(self, session_manager, config):
        """
        Initialize with session manager and config
        
        Args:
            session_manager: Session manager for HTTP requests
            config: Configuration dictionary
        """
        self.session_manager = session_manager
        self.config = config
        self.visited = set()
        self.to_visit = set()
        self.base_domain = None
        self.max_pages = config.get("max_crawl_pages", 100)
        self.max_depth = config.get("max_depth", 3)
        self.exclusions = config.get("exclusions", [".jpg", ".png", ".css", ".js"])
    
    async def crawl(self, start_url):
        """
        Crawl a website starting from a URL
        
        Args:
            start_url: URL to start crawling from
            
        Returns:
            set: Set of discovered URLs
        """
        self.visited = set()
        self.to_visit = {start_url}
        parsed = urlparse(start_url)
        self.base_domain = parsed.netloc
        
        logger.info(f"Starting crawl from {start_url} with max {self.max_pages} pages and depth {self.max_depth}")
        
        current_depth = 0
        urls_at_current_depth = list(self.to_visit)
        urls_at_next_depth = []
        
        while self.to_visit and len(self.visited) < self.max_pages and current_depth < self.max_depth:
            logger.debug(f"Crawling depth {current_depth}, URLs to visit: {len(urls_at_current_depth)}")
            
            # Process all URLs at the current depth concurrently
            tasks = []
            for url in urls_at_current_depth:
                tasks.append(self._process_url(url, urls_at_next_depth))
            
            await asyncio.gather(*tasks)
            
            # Move to the next depth
            urls_at_current_depth = urls_at_next_depth.copy()
            urls_at_next_depth = []
            current_depth += 1
        
        logger.info(f"Crawling completed. Visited {len(self.visited)} URLs at {current_depth} depth levels")
        return self.visited
    
    async def _process_url(self, url, urls_at_next_depth):
        """
        Process a single URL in the crawl
        
        Args:
            url: URL to process
            urls_at_next_depth: List to store URLs for the next depth level
        """
        if url in self.visited or self._should_exclude(url):
            self.to_visit.discard(url)
            return
        
        try:
            logger.debug(f"Crawling {url}")
            self.visited.add(url)
            self.to_visit.discard(url)
            
            response = await self.session_manager.get(url)
            
            # Skip non-HTML responses
            content_type = response.headers.get('content-type', '').lower()
            if 'text/html' not in content_type:
                return
            
            # Parse HTML for links
            soup = BeautifulSoup(await response.text(), 'html.parser')
            
            # Extract links from anchors
            for a_tag in soup.find_all('a', href=True):
                href = a_tag['href']
                absolute_url = urljoin(url, href)
                
                # Only follow links to the same domain
                parsed = urlparse(absolute_url)
                if parsed.netloc == self.base_domain and absolute_url not in self.visited and len(self.visited) < self.max_pages:
                    if not self._should_exclude(absolute_url):
                        self.to_visit.add(absolute_url)
                        urls_at_next_depth.append(absolute_url)
            
            # Extract form actions
            for form in soup.find_all('form'):
                action = form.get('action')
                if action:
                    absolute_url = urljoin(url, action)
                    parsed = urlparse(absolute_url)
                    if parsed.netloc == self.base_domain and absolute_url not in self.visited and len(self.visited) < self.max_pages:
                        if not self._should_exclude(absolute_url):
                            self.to_visit.add(absolute_url)
                            urls_at_next_depth.append(absolute_url)
            
            # Small delay to avoid overwhelming the server
            await asyncio.sleep(self.config.get("scan_delay", 0.5))
            
        except Exception as e:
            logger.error(f"Error crawling {url}: {str(e)}")
    
    def _should_exclude(self, url):
        """
        Check if a URL should be excluded from crawling
        
        Args:
            url: URL to check
            
        Returns:
            bool: True if URL should be excluded, False otherwise
        """
        parsed = urlparse(url)
        path = parsed.path.lower()
        
        # Check for file extensions to exclude
        for ext in self.exclusions:
            if path.endswith(ext):
                return True
        
        return False
