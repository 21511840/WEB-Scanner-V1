import os
import json
import time
import logging
import asyncio
import aiohttp
from urllib.parse import urlparse, urljoin
from datetime import datetime
from scanner.crawler import Crawler
from scanner.vulnerabilities import VulnerabilityChecks
from scanner.session_manager import SessionManager
from scanner.ai_detector import AIDetector
from scanner.report import Report

logger = logging.getLogger(__name__)

class VulnerabilityScanner:
    """
    Core scanner class that orchestrates the vulnerability scanning process.
    """
    def __init__(self, config_file="config.json"):
        """
        Initialize the scanner with configuration.
        
        Args:
            config_file: Path to the configuration file
        """
        self.config = self._load_config(config_file)
        self.session_manager = SessionManager(self.config)
        self.crawler = Crawler(self.session_manager, self.config)
        self.vulnerability_checks = VulnerabilityChecks(self.session_manager, self.config)
        self.ai_detector = AIDetector()
        self.vulnerabilities = []
        self.scan_id = None
        self.target_url = None
        self.start_time = None
        self.end_time = None
    
    def _load_config(self, config_file):
        """
        Load configuration from a JSON file
        
        Args:
            config_file: Path to the configuration file
            
        Returns:
            dict: Configuration dictionary
        """
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                return json.load(f)
        else:
            logger.warning(f"Configuration file {config_file} not found, using default configuration")
            # Return a minimal default configuration
            return {
                "xss_payloads": ["<script>alert('xss')</script>"],
                "sql_payloads": ["' OR 1=1 --"],
                "csrf_fields": ["csrf_token", "csrf"],
                "scan_delay": 0.5,
                "max_threads": 5,
                "max_crawl_pages": 50,
                "max_depth": 3,
                "request_timeout": 10
            }
    
    async def scan(self, target_url, login_url=None, username=None, password=None, 
                  max_pages=None, max_depth=None, scan_id=None):
        """
        Start a scan on the target URL
        
        Args:
            target_url: The URL to scan
            login_url: URL for login if authentication is required
            username: Username for authentication
            password: Password for authentication
            max_pages: Maximum number of pages to scan
            max_depth: Maximum depth to crawl
            scan_id: Optional scan ID for database reference
            
        Returns:
            dict: Scan results
        """
        self.target_url = target_url
        self.scan_id = scan_id
        self.start_time = datetime.now()
        self.vulnerabilities = []
        
        logger.info(f"Starting scan on {target_url}")
        
        # Override configuration with parameters if provided
        if max_pages:
            self.config["max_crawl_pages"] = max_pages
        if max_depth:
            self.config["max_depth"] = max_depth
        
        # Initialize session and login if credentials are provided
        await self.session_manager.initialize()
        if login_url and username and password:
            logger.info(f"Attempting login at {login_url}")
            login_result = await self.session_manager.login(login_url, username, password)
            logger.info(f"Login result: {login_result}")
        
        # Crawl the website to discover pages
        logger.info("Starting website crawling...")
        discovered_urls = await self.crawler.crawl(target_url)
        logger.info(f"Discovered {len(discovered_urls)} URLs")
        
        # Perform vulnerability checks on each discovered URL
        scan_tasks = []
        semaphore = asyncio.Semaphore(self.config.get("max_threads", 5))
        
        async def scan_url_with_semaphore(url):
            async with semaphore:
                return await self._scan_url(url)
        
        for url in discovered_urls:
            scan_tasks.append(scan_url_with_semaphore(url))
        
        # Gather results from all scan tasks
        results = await asyncio.gather(*scan_tasks)
        for url_results in results:
            self.vulnerabilities.extend(url_results)
        
        # Apply AI detection to improve results
        self.vulnerabilities = await self.ai_detector.enhance_results(target_url, self.vulnerabilities)
        
        # Clean up the session
        await self.session_manager.close()
        
        self.end_time = datetime.now()
        scan_duration = (self.end_time - self.start_time).total_seconds()
        
        logger.info(f"Scan completed in {scan_duration:.2f} seconds, found {len(self.vulnerabilities)} vulnerabilities")
        
        # Generate report
        report = Report()
        report_data = report.generate(
            target_url=self.target_url,
            vulnerabilities=self.vulnerabilities,
            scan_info={
                "start_time": self.start_time,
                "end_time": self.end_time,
                "duration": scan_duration,
                "urls_scanned": len(discovered_urls)
            }
        )
        
        return report_data
    
    async def _scan_url(self, url):
        """
        Scan a single URL for vulnerabilities
        
        Args:
            url: The URL to scan
            
        Returns:
            list: List of vulnerabilities found
        """
        url_vulnerabilities = []
        
        try:
            logger.debug(f"Scanning {url}")
            
            # Perform basic checks
            url_vulnerabilities.extend(await self.vulnerability_checks.check_security_headers(url))
            url_vulnerabilities.extend(await self.vulnerability_checks.check_csrf(url))
            url_vulnerabilities.extend(await self.vulnerability_checks.check_information_disclosure(url))
            
            # Perform active checks if the URL has parameters
            parsed_url = urlparse(url)
            if parsed_url.query:
                url_vulnerabilities.extend(await self.vulnerability_checks.check_xss(url))
                url_vulnerabilities.extend(await self.vulnerability_checks.check_sql_injection(url))
                url_vulnerabilities.extend(await self.vulnerability_checks.check_open_redirect(url))
                url_vulnerabilities.extend(await self.vulnerability_checks.check_lfi(url))
            
            # Add form-based checks
            url_vulnerabilities.extend(await self.vulnerability_checks.check_forms(url))
            
            # Small delay to avoid overwhelming the server
            await asyncio.sleep(self.config.get("scan_delay", 0.5))
            
        except Exception as e:
            logger.error(f"Error scanning {url}: {str(e)}", exc_info=True)
            url_vulnerabilities.append({
                "severity": "Low",
                "type": "Error",
                "url": url,
                "message": f"Scan failed: {str(e)}"
            })
        
        return url_vulnerabilities
    
    def get_vulnerabilities(self):
        """
        Get all discovered vulnerabilities
        
        Returns:
            list: List of vulnerabilities
        """
        return self.vulnerabilities
