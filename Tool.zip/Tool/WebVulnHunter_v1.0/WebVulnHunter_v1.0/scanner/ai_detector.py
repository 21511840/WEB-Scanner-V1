import logging
import re
import asyncio
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
import numpy as np

logger = logging.getLogger(__name__)

class AIDetector:
    """
    AI-based vulnerability detector using machine learning models
    """
    
    def __init__(self):
        """
        Initialize the AI detector with ML models
        """
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            ngram_range=(1, 3),
            stop_words='english'
        )
        
        self.classifier = RandomForestClassifier(
            n_estimators=10,
            random_state=42
        )
        
        self._train_model()
    
    def _train_model(self):
        """
        Train the machine learning model with sample data
        """
        # Sample training data for vulnerability detection
        # Format: (text, is_vulnerable)
        training_data = [
            ("<script>alert('xss')</script>", 1),
            ("' OR 1=1 --", 1),
            ("admin' --", 1),
            ("../../../../etc/passwd", 1),
            ("Normal content here", 0),
            ("This is a regular text", 0),
            ("Welcome to our website", 0),
            ("mysql error", 1),
            ("sql syntax error", 1),
            ("unclosed quotation mark", 1),
            ("Warning: mysql_query()", 1),
            ("Call to undefined function", 0),
            ("The requested URL was not found", 0),
            ("Server Error in '/' Application", 1),
            ("500 - Internal server error", 1),
            ("Warning: include(", 1),
            ("ORA-00933: SQL command not properly ended", 1),
            ("Microsoft OLE DB Provider for SQL Server", 1),
            ("You have an error in your SQL syntax", 1),
            ("Unclosed quotation mark after the character string", 1),
            ("PostgreSQL query failed", 1),
            ("[ODBC SQL Server Driver]", 1),
            ("mysql_fetch_array()", 1),
            ("A syntax error has occurred", 1),
            ("java.sql.SQLException", 1),
            ("Oracle error", 1),
            ("invalid file name with 20250406", 0),
            ("A client error occurred", 0),
            ("document.getElementById", 0),
            ("function validateForm()", 0),
            ("Please enter your credentials", 0),
            ("file_get_contents", 1),
            ("fopen(", 1),
            ("cross-site scripting", 1),
            ("csrf token", 0),
            ("Illegal mix of collations", 1)
        ]
        
        X_train, y_train = zip(*training_data)
        
        # Transform text data to feature vectors
        X_train_vec = self.tfidf_vectorizer.fit_transform(X_train)
        
        # Train the classifier
        self.classifier.fit(X_train_vec, y_train)
        
        logger.info("AI model training completed")
    
    async def enhance_results(self, base_url, vulnerabilities):
        """
        Enhance vulnerability scanning results with AI detection
        
        Args:
            base_url: Base URL of the scanned website
            vulnerabilities: List of vulnerabilities found
            
        Returns:
            list: Enhanced vulnerabilities list
        """
        # Create a copy of the original vulnerabilities
        enhanced_vulnerabilities = vulnerabilities.copy()
        
        # Organize vulnerabilities by URL for AI analysis
        urls_to_analyze = {}
        for vuln in vulnerabilities:
            url = vuln.get("url", "")
            if url and url not in urls_to_analyze:
                urls_to_analyze[url] = []
            if url:
                urls_to_analyze[url].append(vuln)
        
        # Process each URL
        for url, url_vulns in urls_to_analyze.items():
            try:
                # Check if we already have ML detected vulnerabilities for this URL
                if any(v.get("type") == "ML Detection" for v in url_vulns):
                    continue
                
                # Skip URLs with a high number of vulnerabilities as they're likely already well-analyzed
                if len(url_vulns) > 5:
                    continue
                
                # Get content for AI analysis
                content = await self._get_content(url)
                if not content:
                    continue
                
                # Check if content has potential vulnerabilities using AI
                if self._detect_potential_vulnerabilities(content):
                    enhanced_vulnerabilities.append({
                        "severity": "Medium",
                        "type": "ML Detection",
                        "url": url,
                        "message": "ML-detected potential vulnerability"
                    })
            
            except Exception as e:
                logger.error(f"Error in AI analysis for {url}: {str(e)}")
        
        return enhanced_vulnerabilities
    
    async def _get_content(self, url):
        """
        Get content from a URL for AI analysis
        
        Args:
            url: URL to get content from
            
        Returns:
            str: Page content
        """
        try:
            # This is a placeholder. In a real implementation, we would use
            # the session manager to get the content, but here we use a simplified approach
            # to avoid circular dependencies
            from aiohttp import ClientSession
            async with ClientSession() as session:
                async with session.get(url, timeout=10) as response:
                    return await response.text()
        except Exception as e:
            logger.error(f"Error getting content for AI analysis from {url}: {str(e)}")
            return ""
    
    def _detect_potential_vulnerabilities(self, content):
        """
        Use the trained ML model to detect potential vulnerabilities
        
        Args:
            content: Content to analyze
            
        Returns:
            bool: True if potential vulnerabilities detected, False otherwise
        """
        try:
            # Clean content - remove HTML tags, etc.
            cleaned_content = self._clean_content(content)
            
            # Create chunks of text for analysis (to handle large pages)
            chunks = self._create_text_chunks(cleaned_content)
            
            # Transform and predict
            for chunk in chunks:
                X_vec = self.tfidf_vectorizer.transform([chunk])
                prediction = self.classifier.predict(X_vec)
                
                # If any chunk is classified as vulnerable, return True
                if prediction[0] == 1:
                    return True
            
            # Check for high-confidence vulnerability patterns
            patterns = [
                r'sql.+?error',
                r'exception.+?stack.+?trace',
                r'([\'"]).*?\1\s*[,;]\s*\w+\s*\(',
                r'SELECT.+?FROM.+?WHERE',
                r'<script>.+?</script>',
                r'password\s*=\s*([\'"]).*?\1',
                r'admin.*password',
                r'root:.+?:0:0:'
            ]
            
            for pattern in patterns:
                if re.search(pattern, cleaned_content, re.IGNORECASE):
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error in vulnerability detection: {str(e)}")
            return False
    
    def _clean_content(self, content):
        """
        Clean HTML content for analysis
        
        Args:
            content: HTML content
            
        Returns:
            str: Cleaned content
        """
        # Remove HTML tags
        content = re.sub(r'<[^>]*>', ' ', content)
        
        # Remove extra whitespace
        content = re.sub(r'\s+', ' ', content).strip()
        
        return content
    
    def _create_text_chunks(self, text, chunk_size=1000, overlap=100):
        """
        Create overlapping chunks of text for analysis
        
        Args:
            text: Text to chunk
            chunk_size: Size of each chunk
            overlap: Overlap between chunks
            
        Returns:
            list: List of text chunks
        """
        chunks = []
        
        if len(text) <= chunk_size:
            chunks.append(text)
        else:
            start = 0
            while start < len(text):
                end = min(start + chunk_size, len(text))
                chunks.append(text[start:end])
                start += (chunk_size - overlap)
        
        return chunks
