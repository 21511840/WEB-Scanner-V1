import os
import json
import logging
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from scanner.utils import get_timestamp, sort_vulnerabilities, get_vulnerability_stats

logger = logging.getLogger(__name__)

class Report:
    """
    Generate vulnerability scan reports
    """
    
    def __init__(self):
        """
        Initialize the report generator
        """
        self.template_html = None
    
    def generate(self, target_url, vulnerabilities, scan_info):
        """
        Generate a vulnerability report
        
        Args:
            target_url: Target URL
            vulnerabilities: List of vulnerabilities found
            scan_info: Dictionary with scan information
            
        Returns:
            dict: Report data
        """
        logger.info(f"Generating report for {target_url} with {len(vulnerabilities)} vulnerabilities")
        
        # Sort vulnerabilities by severity
        sorted_vulnerabilities = sort_vulnerabilities(vulnerabilities)
        
        # Get vulnerability statistics
        stats = get_vulnerability_stats(vulnerabilities)
        
        # Generate report data
        report_data = {
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'target_url': target_url,
            'scan_info': scan_info,
            'vulnerabilities': sorted_vulnerabilities,
            'stats': stats
        }
        
        return report_data
    
    def save_json(self, report_data, filepath=None):
        """
        Save report as JSON
        
        Args:
            report_data: Report data
            filepath: Path to save the report to
            
        Returns:
            str: Path to the saved report
        """
        if not filepath:
            os.makedirs('reports', exist_ok=True)
            filename = f"vuln_report_{get_timestamp()}.json"
            filepath = os.path.join('reports', filename)
        
        with open(filepath, 'w') as f:
            json.dump(report_data, f, indent=4, default=str)
        
        logger.info(f"Report saved to {filepath}")
        return filepath
    
    def save_txt(self, report_data, filepath=None):
        """
        Save report as plain text
        
        Args:
            report_data: Report data
            filepath: Path to save the report to
            
        Returns:
            str: Path to the saved report
        """
        if not filepath:
            os.makedirs('reports', exist_ok=True)
            filename = f"vuln_report_{get_timestamp()}.txt"
            filepath = os.path.join('reports', filename)
        
        with open(filepath, 'w') as f:
            # Write header
            f.write(f"Vulnerability Scan Report\n")
            f.write(f"========================\n\n")
            
            # Write summary
            f.write(f"Target: {report_data['target_url']}\n")
            f.write(f"Date: {report_data['timestamp']}\n")
            f.write(f"Scan Duration: {report_data['scan_info']['duration']:.2f} seconds\n")
            f.write(f"Total URLs Scanned: {report_data['scan_info']['urls_scanned']}\n\n")
            
            # Write statistics
            f.write("Vulnerability Statistics\n")
            f.write("------------------------\n")
            f.write(f"Total Vulnerabilities: {report_data['stats']['total']}\n\n")
            
            f.write("By Severity:\n")
            for severity, count in report_data['stats']['by_severity'].items():
                if count > 0:
                    f.write(f"  {severity}: {count}\n")
            
            f.write("\nBy Type:\n")
            for vuln_type, count in report_data['stats']['by_type'].items():
                f.write(f"  {vuln_type}: {count}\n")
            
            f.write("\n\nDetailed Findings\n")
            f.write("=================\n\n")
            
            # Write vulnerabilities
            for vuln in report_data['vulnerabilities']:
                f.write(f"[{vuln['severity']}] {vuln['type']} at {vuln['url']}: {vuln['message']}\n\n")
        
        logger.info(f"Text report saved to {filepath}")
        return filepath
        
    def save_docx(self, report_data, filepath=None, website_name=None):
        """
        Save report as a DOCX document with detailed information about each vulnerability
        
        Args:
            report_data: Report data
            filepath: Path to save the report to
            website_name: Name of the website (optional)
            
        Returns:
            str: Path to the saved report
        """
        if not filepath:
            os.makedirs('reports', exist_ok=True)
            filename = f"Report_of_{website_name or 'website'}_{get_timestamp()}.docx"
            filepath = os.path.join('reports', filename)
        
        # Create document
        doc = Document()
        
        # Set document title
        title = doc.add_heading(f"Report of {website_name or 'website'}", level=1)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add target URL
        doc.add_paragraph("")
        doc.add_paragraph("")
        target_para = doc.add_paragraph("The target link: ")
        target_para.add_run(report_data['target_url']).bold = True
        
        # Add list of vulnerabilities
        vuln_list_para = doc.add_paragraph("The found bugs: ")
        vuln_names = []
        for vuln in report_data['vulnerabilities']:
            vuln_names.append(f"{vuln['severity']} - {vuln['type']}: {vuln['message']}")
        vuln_list_para.add_run(' || '.join(vuln_names)).bold = True
        
        # Add table header
        doc.add_paragraph("Fill this table")
        doc.add_paragraph("")
        
        # Create table
        table = doc.add_table(rows=1, cols=6)
        table.style = 'Table Grid'
        
        # Set column widths
        for i, width in enumerate([1.5, 1.5, 1.5, 1.5, 2.5, 2.5]):
            for cell in table.columns[i].cells:
                cell.width = Inches(width)
        
        # Set table headers
        header_cells = table.rows[0].cells
        header_cells[0].text = "The vulnerable subdomain"
        header_cells[1].text = "The bug name"
        header_cells[2].text = "The vulnerable parameter"
        header_cells[3].text = "The worked payload"
        header_cells[4].text = "The full request that had sent to get the bug"
        header_cells[5].text = "The full response that had been received"
        
        # Add vulnerability details to table
        for vuln in report_data['vulnerabilities']:
            row_cells = table.add_row().cells
            
            # Extract domain from URL
            from urllib.parse import urlparse
            parsed_url = urlparse(vuln.get('url', ''))
            subdomain = parsed_url.netloc
            
            # Subdomain
            row_cells[0].text = subdomain
            
            # Bug name
            row_cells[1].text = f"{vuln.get('type', 'Unknown')} - {vuln.get('severity', 'Unknown')}"
            
            # Vulnerable parameter
            param = vuln.get('details', {}).get('parameter', 'N/A')
            row_cells[2].text = param
            
            # Worked payload
            payload = vuln.get('details', {}).get('payload', 'N/A')
            row_cells[3].text = payload
            
            # Full request
            request = vuln.get('details', {}).get('request', 'N/A')
            row_cells[4].text = request
            
            # Full response
            response = vuln.get('details', {}).get('response', 'N/A')
            row_cells[5].text = response
        
        # Save document
        doc.save(filepath)
        
        logger.info(f"DOCX report saved to {filepath}")
        return filepath
