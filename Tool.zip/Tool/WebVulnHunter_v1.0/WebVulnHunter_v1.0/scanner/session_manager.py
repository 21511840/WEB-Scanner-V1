import logging
import asyncio
import aiohttp
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

class SessionManager:
    """
    Manage HTTP sessions and authentication for scanning
    """
    
    def __init__(self, config):
        """
        Initialize with configuration
        
        Args:
            config: Configuration dictionary
        """
        self.config = config
        self.cookies = {}
        self.session = None
        self.headers = {
            'User-Agent': config.get('user_agent', 'VulnScanner/1.0'),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        self.timeout = aiohttp.ClientTimeout(total=config.get('request_timeout', 10))
    
    async def initialize(self):
        """
        Initialize the HTTP session
        """
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(headers=self.headers, timeout=self.timeout)
        logger.debug("Session initialized")
    
    async def login(self, login_url, username, password):
        """
        Attempt to log in to a website
        
        Args:
            login_url: URL for login
            username: Username for authentication
            password: Password for authentication
            
        Returns:
            str: Login result message
        """
        await self.initialize()
        
        try:
            # First get the login page to capture any CSRF tokens
            async with self.session.get(login_url) as response:
                html = await response.text()
                
                # Look for a CSRF token in the form
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(html, 'html.parser')
                
                form = soup.find('form')
                if not form:
                    return "Login failed: No form found on login page"
                
                # Extract all form fields
                data = {}
                for input_tag in form.find_all('input'):
                    name = input_tag.get('name')
                    value = input_tag.get('value', '')
                    input_type = input_tag.get('type', '')
                    
                    if name:
                        # Skip submit buttons
                        if input_type != 'submit':
                            data[name] = value
                
                # Add username and password to the form data
                username_field = self._find_username_field(data.keys())
                password_field = self._find_password_field(data.keys())
                
                if username_field:
                    data[username_field] = username
                else:
                    # If we can't find a username field, try common names
                    data['username'] = username
                
                if password_field:
                    data[password_field] = password
                else:
                    # If we can't find a password field, try common names
                    data['password'] = password
                
                # Get the form action
                action = form.get('action')
                if action:
                    login_url = urljoin(login_url, action)
                
                # Submit the login form
                method = form.get('method', 'post').lower()
                
                if method == 'get':
                    async with self.session.get(login_url, params=data) as login_response:
                        self.cookies.update(login_response.cookies)
                        return "Login completed (GET)"
                else:  # default to POST
                    async with self.session.post(login_url, data=data) as login_response:
                        self.cookies.update(login_response.cookies)
                        
                        # Check login success based on response
                        if login_response.status == 200:
                            login_text = await login_response.text()
                            
                            # Check for common login success/failure indicators
                            if 'logout' in login_text.lower() or 'sign out' in login_text.lower():
                                return "Login successful"
                            elif 'invalid' in login_text.lower() or 'failed' in login_text.lower() or 'incorrect' in login_text.lower():
                                return "Login failed: Invalid credentials"
                            else:
                                return "Login completed (status undetermined)"
                        elif login_response.status == 302:  # Redirect after login is common
                            return "Login successful (redirect)"
                        else:
                            return f"Login status unclear: HTTP {login_response.status}"
        
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            return f"Login failed: {str(e)}"
    
    def _find_username_field(self, field_names):
        """
        Find the username field in a list of form field names
        
        Args:
            field_names: List of form field names
            
        Returns:
            str: Username field name or None
        """
        username_fields = ['username', 'user', 'email', 'login', 'userid', 'name']
        for field in field_names:
            if field.lower() in username_fields or any(uf in field.lower() for uf in username_fields):
                return field
        return None
    
    def _find_password_field(self, field_names):
        """
        Find the password field in a list of form field names
        
        Args:
            field_names: List of form field names
            
        Returns:
            str: Password field name or None
        """
        password_fields = ['password', 'pass', 'pwd']
        for field in field_names:
            if field.lower() in password_fields or any(pf in field.lower() for pf in password_fields):
                return field
        return None
    
    async def get(self, url, allow_redirects=True):
        """
        Send a GET request
        
        Args:
            url: URL to request
            allow_redirects: Whether to follow redirects
            
        Returns:
            Response: HTTP response
        """
        await self.initialize()
        
        try:
            return await self.session.get(
                url,
                cookies=self.cookies,
                allow_redirects=allow_redirects,
                timeout=self.timeout
            )
        except Exception as e:
            logger.error(f"GET request error for {url}: {str(e)}")
            raise
    
    async def post(self, url, data=None, json=None, allow_redirects=True):
        """
        Send a POST request
        
        Args:
            url: URL to request
            data: Form data to send
            json: JSON data to send
            allow_redirects: Whether to follow redirects
            
        Returns:
            Response: HTTP response
        """
        await self.initialize()
        
        try:
            return await self.session.post(
                url,
                data=data,
                json=json,
                cookies=self.cookies,
                allow_redirects=allow_redirects,
                timeout=self.timeout
            )
        except Exception as e:
            logger.error(f"POST request error for {url}: {str(e)}")
            raise
    
    async def close(self):
        """
        Close the HTTP session
        """
        if self.session and not self.session.closed:
            await self.session.close()
            logger.debug("Session closed")
