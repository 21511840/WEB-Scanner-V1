#!/usr/bin/env python3
import asyncio
from scanner.core import VulnerabilityScanner

async def test_scan():
    scanner = VulnerabilityScanner()
    print('Starting test scan...')
    result = await scanner.scan('https://httpbin.org', max_depth=1, max_pages=2)
    print(f'Test scan completed with {len(scanner.vulnerabilities)} findings')
    
    # Print the findings
    if scanner.vulnerabilities:
        print("\nVulnerabilities found:")
        for i, vuln in enumerate(scanner.vulnerabilities):
            print(f"{i+1}. {vuln.get('severity')} - {vuln.get('type')}: {vuln.get('message')}")
    else:
        print("No vulnerabilities found.")

if __name__ == "__main__":
    asyncio.run(test_scan())