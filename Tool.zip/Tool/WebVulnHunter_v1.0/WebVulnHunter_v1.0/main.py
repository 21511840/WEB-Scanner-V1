#!/usr/bin/env python3
import argparse
import asyncio
import sys
import logging
from scanner.core import VulnerabilityScanner
from interfaces.cli import cli_scan
from interfaces.gui import start_gui
from app import app

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("vuln_scanner.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def main():
    """
    Main entry point for the application with three possible interfaces:
    1. CLI - Command Line Interface
    2. GUI - Graphical User Interface
    3. Web - Web Application Interface
    """
    parser = argparse.ArgumentParser(description='Web Vulnerability Scanner with CLI, GUI, and Web interfaces')
    
    # Add command-line arguments
    parser.add_argument('--url', help='URL to scan')
    parser.add_argument('--gui', action='store_true', help='Launch the GUI')
    parser.add_argument('--web', action='store_true', help='Launch the Web interface')
    parser.add_argument('--threads', type=int, default=5, help='Number of concurrent threads (default: 5)')
    parser.add_argument('--depth', type=int, default=3, help='Crawl depth (default: 3)')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    parser.add_argument('--output', help='Output report file path')
    parser.add_argument('--username', help='Username for authenticated scan')
    parser.add_argument('--password', help='Password for authenticated scan')
    parser.add_argument('--login-url', help='Login URL for authenticated scan')
    
    args = parser.parse_args()
    
    # Set logging level based on verbose flag
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Determine which interface to use
    if args.gui:
        logger.info("Starting GUI interface")
        start_gui()
    elif args.web:
        logger.info("Starting Web interface")
        app.run(host="0.0.0.0", port=5000, debug=True)
    elif args.url:
        logger.info(f"Starting CLI scan for {args.url}")
        asyncio.run(cli_scan(args))
    else:
        parser.print_help()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Scanner interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        sys.exit(1)
