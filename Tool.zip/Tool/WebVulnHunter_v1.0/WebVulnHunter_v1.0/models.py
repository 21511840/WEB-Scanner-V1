from datetime import datetime
from app import db
from flask_login import UserMixin
from sqlalchemy.dialects.sqlite import JSON
import json

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    scans = db.relationship('Scan', backref='user', lazy='dynamic')

class Scan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    target_url = db.Column(db.String(255), nullable=False)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), default='in_progress')
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    vulnerabilities = db.relationship('Vulnerability', backref='scan', lazy='dynamic')
    
    def duration(self):
        """Calculate scan duration in seconds"""
        if not self.completed_at:
            return 0
        delta = self.completed_at - self.started_at
        return delta.total_seconds()
    
    def summary(self):
        """Generate a summary of the vulnerabilities found"""
        counts = {
            'critical': 0,
            'high': 0,
            'medium': 0,
            'low': 0,
            'info': 0,
            'total': 0
        }
        
        for vuln in self.vulnerabilities:
            counts[vuln.severity.lower()] += 1
            counts['total'] += 1
        
        return counts

class Vulnerability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scan_id = db.Column(db.Integer, db.ForeignKey('scan.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    url = db.Column(db.String(255))
    severity = db.Column(db.String(20), nullable=False) # Critical, High, Medium, Low, Info
    type = db.Column(db.String(50)) # XSS, SQL Injection, etc.
    found_at = db.Column(db.DateTime, default=datetime.utcnow)
    details = db.Column(JSON, nullable=True) # Additional details about the vulnerability
    
    def set_details(self, details_dict):
        """Set details as JSON"""
        self.details = details_dict
    
    def get_details(self):
        """Get details as dict"""
        return self.details if self.details else {}

class Configuration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @staticmethod
    def get_value(name, default=None):
        """Get configuration value by name"""
        config = Configuration.query.filter_by(name=name).first()
        if not config:
            return default
        try:
            return json.loads(config.value)
        except:
            return config.value
    
    @staticmethod
    def set_value(name, value):
        """Set configuration value"""
        config = Configuration.query.filter_by(name=name).first()
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        
        if config:
            config.value = value
            config.updated_at = datetime.utcnow()
        else:
            config = Configuration(name=name, value=value)
            db.session.add(config)
        
        db.session.commit()
        return config
