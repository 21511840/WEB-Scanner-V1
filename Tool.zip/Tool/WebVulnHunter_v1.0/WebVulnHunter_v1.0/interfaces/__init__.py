"""
Interfaces package for the vulnerability scanner.
This package contains the CLI, GUI, and web interfaces.
"""
