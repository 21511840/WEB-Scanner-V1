import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import threading
import queue
import asyncio
import logging
from datetime import datetime
from scanner.core import VulnerabilityScanner
from scanner.utils import display_time

logger = logging.getLogger(__name__)

class AsyncioThread(threading.Thread):
    """
    Thread for running asyncio event loop
    """
    def __init__(self, loop=None):
        super().__init__()
        self.loop = loop or asyncio.new_event_loop()
        self.daemon = True
        self._stop_event = threading.Event()
        
    def run(self):
        """Set the asyncio loop for this thread"""
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()
    
    def stop(self):
        """Stop the thread"""
        self._stop_event.set()
        self.loop.call_soon_threadsafe(self.loop.stop)
    
    def run_coroutine(self, coro):
        """Run a coroutine in this thread's event loop"""
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

class ScannerGUI:
    """
    GUI for the vulnerability scanner
    """
    def __init__(self, root):
        """
        Initialize the GUI
        
        Args:
            root: Tkinter root window
        """
        self.root = root
        self.root.title("Web Vulnerability Scanner")
        self.root.geometry("900x700")
        self.root.minsize(800, 600)
        
        # Initialize asyncio thread
        self.asyncio_thread = AsyncioThread()
        self.asyncio_thread.start()
        
        # Initialize scanner
        self.scanner = VulnerabilityScanner()
        
        # Queue for communication between threads
        self.queue = queue.Queue()
        
        # Create GUI components
        self.create_widgets()
        
        # Start checking the queue
        self.check_queue()
        
        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
    
    def create_widgets(self):
        """
        Create GUI widgets
        """
        # Main frame with padding
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title label
        title_label = ttk.Label(main_frame, text="Web Vulnerability Scanner", font=("Arial", 16, "bold"))
        title_label.pack(pady=10)
        
        # Notebook (tabs)
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Create tabs
        self.scan_tab = ttk.Frame(self.notebook)
        self.results_tab = ttk.Frame(self.notebook)
        self.config_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.scan_tab, text="Scan")
        self.notebook.add(self.results_tab, text="Results")
        self.notebook.add(self.config_tab, text="Configuration")
        
        # Scan tab
        self.create_scan_tab()
        
        # Results tab
        self.create_results_tab()
        
        # Configuration tab
        self.create_config_tab()
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        status_bar = ttk.Label(main_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def create_scan_tab(self):
        """
        Create the scan tab
        """
        # Frame for input fields
        input_frame = ttk.LabelFrame(self.scan_tab, text="Scan Settings", padding="10")
        input_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # Target URL
        ttk.Label(input_frame, text="Target URL:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.url_var = tk.StringVar()
        self.url_entry = ttk.Entry(input_frame, textvariable=self.url_var, width=50)
        self.url_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        # Authentication frame
        auth_frame = ttk.LabelFrame(self.scan_tab, text="Authentication (Optional)", padding="10")
        auth_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # Login URL
        ttk.Label(auth_frame, text="Login URL:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.login_url_var = tk.StringVar()
        self.login_url_entry = ttk.Entry(auth_frame, textvariable=self.login_url_var, width=50)
        self.login_url_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        # Username
        ttk.Label(auth_frame, text="Username:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.username_var = tk.StringVar()
        self.username_entry = ttk.Entry(auth_frame, textvariable=self.username_var, width=50)
        self.username_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        # Password
        ttk.Label(auth_frame, text="Password:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.password_var = tk.StringVar()
        self.password_entry = ttk.Entry(auth_frame, textvariable=self.password_var, width=50, show="*")
        self.password_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        
        # Advanced settings frame
        adv_frame = ttk.LabelFrame(self.scan_tab, text="Advanced Settings", padding="10")
        adv_frame.pack(fill=tk.X, pady=10, padx=10)
        
        # Crawl depth
        ttk.Label(adv_frame, text="Crawl Depth:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.depth_var = tk.IntVar(value=3)
        self.depth_spinbox = ttk.Spinbox(adv_frame, from_=1, to=10, textvariable=self.depth_var, width=5)
        self.depth_spinbox.grid(row=0, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Max pages
        ttk.Label(adv_frame, text="Max Pages:").grid(row=0, column=2, sticky=tk.W, pady=5, padx=(20, 0))
        self.max_pages_var = tk.IntVar(value=100)
        self.max_pages_spinbox = ttk.Spinbox(adv_frame, from_=10, to=500, textvariable=self.max_pages_var, width=5)
        self.max_pages_spinbox.grid(row=0, column=3, sticky=tk.W, pady=5, padx=5)
        
        # Threads
        ttk.Label(adv_frame, text="Threads:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.threads_var = tk.IntVar(value=5)
        self.threads_spinbox = ttk.Spinbox(adv_frame, from_=1, to=20, textvariable=self.threads_var, width=5)
        self.threads_spinbox.grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Output file
        ttk.Label(adv_frame, text="Output File:").grid(row=1, column=2, sticky=tk.W, pady=5, padx=(20, 0))
        self.output_var = tk.StringVar()
        output_frame = ttk.Frame(adv_frame)
        output_frame.grid(row=1, column=3, sticky=(tk.W, tk.E), pady=5, padx=5)
        self.output_entry = ttk.Entry(output_frame, textvariable=self.output_var, width=20)
        self.output_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.output_btn = ttk.Button(output_frame, text="...", width=3, command=self.browse_output)
        self.output_btn.pack(side=tk.RIGHT)
        
        # Buttons frame
        btn_frame = ttk.Frame(self.scan_tab)
        btn_frame.pack(fill=tk.X, pady=20, padx=10)
        
        # Start scan button
        self.start_btn = ttk.Button(btn_frame, text="Start Scan", command=self.start_scan)
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        # Stop scan button
        self.stop_btn = ttk.Button(btn_frame, text="Stop Scan", command=self.stop_scan, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        # Clear button
        self.clear_btn = ttk.Button(btn_frame, text="Clear", command=self.clear_form)
        self.clear_btn.pack(side=tk.LEFT, padx=5)
        
        # Progress frame
        progress_frame = ttk.LabelFrame(self.scan_tab, text="Progress", padding="10")
        progress_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill=tk.X, pady=5)
        
        # Status text
        self.log_text = scrolledtext.ScrolledText(progress_frame, height=10)
        self.log_text.pack(fill=tk.BOTH, expand=True, pady=5)
        self.log_text.config(state=tk.DISABLED)
    
    def create_results_tab(self):
        """
        Create the results tab
        """
        # Top frame
        top_frame = ttk.Frame(self.results_tab, padding="10")
        top_frame.pack(fill=tk.X)
        
        # Summary frame
        self.summary_frame = ttk.LabelFrame(top_frame, text="Scan Summary", padding="10")
        self.summary_frame.pack(fill=tk.X, side=tk.LEFT, expand=True)
        
        # Target
        ttk.Label(self.summary_frame, text="Target:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.summary_target_var = tk.StringVar()
        ttk.Label(self.summary_frame, textvariable=self.summary_target_var).grid(row=0, column=1, sticky=tk.W, pady=2)
        
        # Scan time
        ttk.Label(self.summary_frame, text="Scan Time:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.summary_time_var = tk.StringVar()
        ttk.Label(self.summary_frame, textvariable=self.summary_time_var).grid(row=1, column=1, sticky=tk.W, pady=2)
        
        # Duration
        ttk.Label(self.summary_frame, text="Duration:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.summary_duration_var = tk.StringVar()
        ttk.Label(self.summary_frame, textvariable=self.summary_duration_var).grid(row=2, column=1, sticky=tk.W, pady=2)
        
        # Total vulnerabilities
        ttk.Label(self.summary_frame, text="Total Vulnerabilities:").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.summary_total_var = tk.StringVar()
        ttk.Label(self.summary_frame, textvariable=self.summary_total_var).grid(row=3, column=1, sticky=tk.W, pady=2)
        
        # Stats frame
        self.stats_frame = ttk.LabelFrame(top_frame, text="Vulnerability Breakdown", padding="10")
        self.stats_frame.pack(fill=tk.X, side=tk.LEFT, expand=True, padx=(10, 0))
        
        # Critical
        ttk.Label(self.stats_frame, text="Critical:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.stats_critical_var = tk.StringVar(value="0")
        ttk.Label(self.stats_frame, textvariable=self.stats_critical_var).grid(row=0, column=1, sticky=tk.W, pady=2)
        
        # High
        ttk.Label(self.stats_frame, text="High:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.stats_high_var = tk.StringVar(value="0")
        ttk.Label(self.stats_frame, textvariable=self.stats_high_var).grid(row=1, column=1, sticky=tk.W, pady=2)
        
        # Medium
        ttk.Label(self.stats_frame, text="Medium:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.stats_medium_var = tk.StringVar(value="0")
        ttk.Label(self.stats_frame, textvariable=self.stats_medium_var).grid(row=2, column=1, sticky=tk.W, pady=2)
        
        # Low
        ttk.Label(self.stats_frame, text="Low:").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.stats_low_var = tk.StringVar(value="0")
        ttk.Label(self.stats_frame, textvariable=self.stats_low_var).grid(row=3, column=1, sticky=tk.W, pady=2)
        
        # Info
        ttk.Label(self.stats_frame, text="Info:").grid(row=4, column=0, sticky=tk.W, pady=2)
        self.stats_info_var = tk.StringVar(value="0")
        ttk.Label(self.stats_frame, textvariable=self.stats_info_var).grid(row=4, column=1, sticky=tk.W, pady=2)
        
        # Results frame
        results_frame = ttk.LabelFrame(self.results_tab, text="Vulnerabilities", padding="10")
        results_frame.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        
        # Create treeview with scrollbar
        columns = ("severity", "type", "url", "message")
        self.tree = ttk.Treeview(results_frame, columns=columns, show="headings")
        
        # Column headings
        self.tree.heading("severity", text="Severity")
        self.tree.heading("type", text="Type")
        self.tree.heading("url", text="URL")
        self.tree.heading("message", text="Message")
        
        # Column widths
        self.tree.column("severity", width=80, anchor=tk.CENTER)
        self.tree.column("type", width=120)
        self.tree.column("url", width=200)
        self.tree.column("message", width=400)
        
        # Scrollbars
        vsb = ttk.Scrollbar(results_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(results_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Pack scrollbars and treeview
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        hsb.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        # Bind double-click to show detail
        self.tree.bind("<Double-1>", self.show_vulnerability_detail)
        
        # Bottom frame for buttons
        bottom_frame = ttk.Frame(self.results_tab, padding="10")
        bottom_frame.pack(fill=tk.X)
        
        # Export button
        self.export_btn = ttk.Button(bottom_frame, text="Export Report", command=self.export_report)
        self.export_btn.pack(side=tk.LEFT, padx=5)
        
        # View detail button
        self.detail_btn = ttk.Button(bottom_frame, text="View Details", command=self.view_selected_detail)
        self.detail_btn.pack(side=tk.LEFT, padx=5)
        
        # Clear results button
        self.clear_results_btn = ttk.Button(bottom_frame, text="Clear Results", command=self.clear_results)
        self.clear_results_btn.pack(side=tk.LEFT, padx=5)
    
    def create_config_tab(self):
        """
        Create the configuration tab
        """
        # Notebook for configuration sections
        config_notebook = ttk.Notebook(self.config_tab)
        config_notebook.pack(fill=tk.BOTH, expand=True, pady=10, padx=10)
        
        # General settings tab
        general_tab = ttk.Frame(config_notebook, padding="10")
        config_notebook.add(general_tab, text="General")
        
        # Max threads
        ttk.Label(general_tab, text="Maximum Threads:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.config_threads_var = tk.IntVar(value=self.scanner.config.get("max_threads", 5))
        threads_spinbox = ttk.Spinbox(general_tab, from_=1, to=20, textvariable=self.config_threads_var, width=5)
        threads_spinbox.grid(row=0, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Scan delay
        ttk.Label(general_tab, text="Scan Delay (seconds):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.config_delay_var = tk.DoubleVar(value=self.scanner.config.get("scan_delay", 0.5))
        delay_spinbox = ttk.Spinbox(general_tab, from_=0.0, to=5.0, increment=0.1, textvariable=self.config_delay_var, width=5)
        delay_spinbox.grid(row=1, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Request timeout
        ttk.Label(general_tab, text="Request Timeout (seconds):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.config_timeout_var = tk.IntVar(value=self.scanner.config.get("request_timeout", 10))
        timeout_spinbox = ttk.Spinbox(general_tab, from_=1, to=60, textvariable=self.config_timeout_var, width=5)
        timeout_spinbox.grid(row=2, column=1, sticky=tk.W, pady=5, padx=5)
        
        # Payloads tab
        payloads_tab = ttk.Frame(config_notebook, padding="10")
        config_notebook.add(payloads_tab, text="Payloads")
        
        # XSS payloads
        ttk.Label(payloads_tab, text="XSS Payloads:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.xss_payloads_text = scrolledtext.ScrolledText(payloads_tab, width=50, height=5)
        self.xss_payloads_text.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        self.xss_payloads_text.insert(tk.END, "\n".join(self.scanner.config.get("xss_payloads", [])))
        
        # SQL injection payloads
        ttk.Label(payloads_tab, text="SQL Injection Payloads:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.sql_payloads_text = scrolledtext.ScrolledText(payloads_tab, width=50, height=5)
        self.sql_payloads_text.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        self.sql_payloads_text.insert(tk.END, "\n".join(self.scanner.config.get("sql_payloads", [])))
        
        # CSRF Fields
        ttk.Label(payloads_tab, text="CSRF Token Fields:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.csrf_fields_text = scrolledtext.ScrolledText(payloads_tab, width=50, height=5)
        self.csrf_fields_text.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=5)
        self.csrf_fields_text.insert(tk.END, "\n".join(self.scanner.config.get("csrf_fields", [])))
        
        # Save button
        save_btn = ttk.Button(self.config_tab, text="Save Configuration", command=self.save_config)
        save_btn.pack(side=tk.RIGHT, padx=10, pady=10)
        
        # Reset button
        reset_btn = ttk.Button(self.config_tab, text="Reset to Defaults", command=self.reset_config)
        reset_btn.pack(side=tk.RIGHT, padx=10, pady=10)
    
    def browse_output(self):
        """
        Open file browser to select output file
        """
        filename = filedialog.asksaveasfilename(
            title="Save Report As",
            filetypes=(("Text files", "*.txt"), ("JSON files", "*.json"), ("All files", "*.*")),
            defaultextension=".txt"
        )
        if filename:
            self.output_var.set(filename)
    
    def start_scan(self):
        """
        Start the vulnerability scan
        """
        url = self.url_var.get().strip()
        if not url:
            messagebox.showerror("Error", "Please enter a target URL")
            return
        
        # Update UI
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.clear_btn.config(state=tk.DISABLED)
        self.progress_var.set(0)
        self.log("Starting scan for " + url)
        self.status_var.set("Scanning...")
        
        # Update scanner config
        self.scanner.config["max_threads"] = self.threads_var.get()
        self.scanner.config["max_depth"] = self.depth_var.get()
        self.scanner.config["max_crawl_pages"] = self.max_pages_var.get()
        
        # Start scan in asyncio thread
        self.scan_future = self.asyncio_thread.run_coroutine(
            self.scanner.scan(
                target_url=url,
                login_url=self.login_url_var.get().strip(),
                username=self.username_var.get().strip(),
                password=self.password_var.get().strip(),
                max_pages=self.max_pages_var.get(),
                max_depth=self.depth_var.get()
            )
        )
        
        # Start monitoring scan progress
        self.monitor_scan()
    
    def stop_scan(self):
        """
        Stop the ongoing scan
        """
        if hasattr(self, 'scan_future') and not self.scan_future.done():
            # Signal to cancel the scan
            self.log("Stopping scan...")
            self.scan_future.cancel()
            
            # Update UI
            self.start_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.DISABLED)
            self.clear_btn.config(state=tk.NORMAL)
            self.status_var.set("Scan stopped")
            self.log("Scan stopped by user")
    
    def monitor_scan(self):
        """
        Monitor the progress of the scan
        """
        if not hasattr(self, 'scan_future') or self.scan_future.done():
            # Scan is complete or cancelled
            if hasattr(self, 'scan_future') and not self.scan_future.cancelled():
                try:
                    # Get scan results
                    report_data = self.scan_future.result()
                    
                    # Update scan status
                    self.log("Scan completed!")
                    self.status_var.set("Scan completed")
                    self.progress_var.set(100)
                    
                    # Display results in the results tab
                    self.display_results(report_data)
                    
                    # Switch to results tab
                    self.notebook.select(self.results_tab)
                except Exception as e:
                    self.log(f"Error during scan: {str(e)}")
                    self.status_var.set("Scan failed")
                    messagebox.showerror("Scan Error", f"An error occurred during the scan:\n{str(e)}")
            
            # Reset UI
            self.start_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.DISABLED)
            self.clear_btn.config(state=tk.NORMAL)
            
            return
        
        # Update progress
        estimated_progress = 0
        if hasattr(self.scanner, 'crawler') and hasattr(self.scanner.crawler, 'visited'):
            max_pages = self.max_pages_var.get()
            pages_visited = len(self.scanner.crawler.visited)
            estimated_progress = min(95, int((pages_visited / max_pages) * 100))
        
        self.progress_var.set(estimated_progress)
        self.status_var.set(f"Scanning... {estimated_progress}%")
        
        # Log some info
        if hasattr(self.scanner, 'vulnerabilities'):
            self.log(f"Found {len(self.scanner.vulnerabilities)} vulnerabilities so far...")
        
        # Check again in 500 ms
        self.root.after(500, self.monitor_scan)
    
    def display_results(self, report_data):
        """
        Display scan results in the results tab
        
        Args:
            report_data: Report data dictionary
        """
        # Clear existing results
        self.clear_results()
        
        # Update summary information
        self.summary_target_var.set(report_data.get('target_url', 'N/A'))
        self.summary_time_var.set(report_data.get('timestamp', 'N/A'))
        self.summary_duration_var.set(f"{report_data.get('scan_info', {}).get('duration', 0):.2f} seconds")
        self.summary_total_var.set(str(len(report_data.get('vulnerabilities', []))))
        
        # Update vulnerability statistics
        severity_counts = {
            'Critical': 0,
            'High': 0,
            'Medium': 0,
            'Low': 0,
            'Info': 0
        }
        
        for vuln in report_data.get('vulnerabilities', []):
            severity = vuln.get('severity', 'Low')
            if severity in severity_counts:
                severity_counts[severity] += 1
        
        self.stats_critical_var.set(str(severity_counts.get('Critical', 0)))
        self.stats_high_var.set(str(severity_counts.get('High', 0)))
        self.stats_medium_var.set(str(severity_counts.get('Medium', 0)))
        self.stats_low_var.set(str(severity_counts.get('Low', 0)))
        self.stats_info_var.set(str(severity_counts.get('Info', 0)))
        
        # Populate treeview with vulnerabilities
        for i, vuln in enumerate(report_data.get('vulnerabilities', [])):
            severity = vuln.get('severity', 'Low')
            vuln_type = vuln.get('type', 'Unknown')
            url = vuln.get('url', 'N/A')
            message = vuln.get('message', 'No details')
            
            item_id = self.tree.insert('', 'end', text=str(i),
                                     values=(severity, vuln_type, url, message))
            
            # Set tags for severity colors
            if severity == 'Critical':
                self.tree.item(item_id, tags=('critical',))
            elif severity == 'High':
                self.tree.item(item_id, tags=('high',))
            elif severity == 'Medium':
                self.tree.item(item_id, tags=('medium',))
            elif severity == 'Low':
                self.tree.item(item_id, tags=('low',))
            else:
                self.tree.item(item_id, tags=('info',))
        
        # Configure tag colors
        self.tree.tag_configure('critical', background='#ffcccc')
        self.tree.tag_configure('high', background='#ffddcc')
        self.tree.tag_configure('medium', background='#ffffcc')
        self.tree.tag_configure('low', background='#ccffcc')
        self.tree.tag_configure('info', background='#ccccff')
        
        # Store report data for later use
        self.current_report = report_data
    
    def show_vulnerability_detail(self, event):
        """
        Show details for a vulnerability on double-click
        
        Args:
            event: Event information
        """
        self.view_selected_detail()
    
    def view_selected_detail(self):
        """
        Show details for the selected vulnerability
        """
        selected_items = self.tree.selection()
        if not selected_items:
            messagebox.showinfo("Info", "Please select a vulnerability to view details")
            return
        
        # Get the selected vulnerability
        item_id = selected_items[0]
        item_idx = int(self.tree.item(item_id, "text"))
        
        if not hasattr(self, 'current_report') or not self.current_report:
            messagebox.showinfo("Info", "No vulnerability data available")
            return
        
        vuln = self.current_report.get('vulnerabilities', [])[item_idx]
        
        # Create detail window
        detail_window = tk.Toplevel(self.root)
        detail_window.title("Vulnerability Details")
        detail_window.geometry("600x400")
        detail_window.minsize(500, 300)
        
        # Create content frame
        frame = ttk.Frame(detail_window, padding="10")
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Vulnerability detail fields
        ttk.Label(frame, text="Severity:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W, pady=5)
        ttk.Label(frame, text=vuln.get('severity', 'Unknown')).grid(row=0, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(frame, text="Type:", font=("Arial", 10, "bold")).grid(row=1, column=0, sticky=tk.W, pady=5)
        ttk.Label(frame, text=vuln.get('type', 'Unknown')).grid(row=1, column=1, sticky=tk.W, pady=5)
        
        ttk.Label(frame, text="URL:", font=("Arial", 10, "bold")).grid(row=2, column=0, sticky=tk.W, pady=5)
        url_entry = ttk.Entry(frame, width=60)
        url_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)
        url_entry.insert(0, vuln.get('url', 'N/A'))
        url_entry.config(state="readonly")
        
        ttk.Label(frame, text="Description:", font=("Arial", 10, "bold")).grid(row=3, column=0, sticky=tk.W, pady=5)
        desc_text = scrolledtext.ScrolledText(frame, width=60, height=3)
        desc_text.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)
        desc_text.insert(tk.END, vuln.get('message', 'No description available'))
        desc_text.config(state=tk.DISABLED)
        
        # Additional details if available
        if 'details' in vuln and vuln['details']:
            ttk.Label(frame, text="Details:", font=("Arial", 10, "bold")).grid(row=4, column=0, sticky=tk.NW, pady=5)
            details_text = scrolledtext.ScrolledText(frame, width=60, height=10)
            details_text.grid(row=4, column=1, sticky=(tk.W, tk.E), pady=5)
            
            # Format the details
            details_str = ""
            for key, value in vuln['details'].items():
                details_str += f"{key}: {value}\n"
            
            details_text.insert(tk.END, details_str)
            details_text.config(state=tk.DISABLED)
        
        # Close button
        ttk.Button(frame, text="Close", command=detail_window.destroy).grid(row=5, column=1, sticky=tk.E, pady=10)
    
    def export_report(self):
        """
        Export the scan report to a file
        """
        if not hasattr(self, 'current_report') or not self.current_report:
            messagebox.showinfo("Info", "No scan results to export")
            return
        
        # Get output file path
        output_path = self.output_var.get().strip()
        if not output_path:
            output_path = filedialog.asksaveasfilename(
                title="Save Report As",
                filetypes=(("Text files", "*.txt"), ("JSON files", "*.json"), ("All files", "*.*")),
                defaultextension=".txt"
            )
            if not output_path:
                return
        
        try:
            # Generate report
            from scanner.report import Report
            report_generator = Report()
            
            # Save report based on file extension
            if output_path.endswith('.json'):
                report_path = report_generator.save_json(self.current_report, output_path)
            else:
                report_path = report_generator.save_txt(self.current_report, output_path)
            
            messagebox.showinfo("Success", f"Report saved to {report_path}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export report: {str(e)}")
    
    def clear_form(self):
        """
        Clear the scan form
        """
        self.url_var.set("")
        self.login_url_var.set("")
        self.username_var.set("")
        self.password_var.set("")
        self.depth_var.set(3)
        self.max_pages_var.set(100)
        self.threads_var.set(5)
        self.output_var.set("")
        self.log_text.config(state=tk.NORMAL)
        self.log_text.delete(1.0, tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.progress_var.set(0)
        self.status_var.set("Ready")
    
    def clear_results(self):
        """
        Clear the results tab
        """
        # Clear treeview
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Reset summary
        self.summary_target_var.set("")
        self.summary_time_var.set("")
        self.summary_duration_var.set("")
        self.summary_total_var.set("0")
        
        # Reset stats
        self.stats_critical_var.set("0")
        self.stats_high_var.set("0")
        self.stats_medium_var.set("0")
        self.stats_low_var.set("0")
        self.stats_info_var.set("0")
        
        # Clear current report
        if hasattr(self, 'current_report'):
            self.current_report = None
    
    def save_config(self):
        """
        Save the configuration
        """
        try:
            # Update general settings
            self.scanner.config["max_threads"] = self.config_threads_var.get()
            self.scanner.config["scan_delay"] = self.config_delay_var.get()
            self.scanner.config["request_timeout"] = self.config_timeout_var.get()
            
            # Update payloads
            self.scanner.config["xss_payloads"] = [line.strip() for line in self.xss_payloads_text.get(1.0, tk.END).strip().split('\n') if line.strip()]
            self.scanner.config["sql_payloads"] = [line.strip() for line in self.sql_payloads_text.get(1.0, tk.END).strip().split('\n') if line.strip()]
            self.scanner.config["csrf_fields"] = [line.strip() for line in self.csrf_fields_text.get(1.0, tk.END).strip().split('\n') if line.strip()]
            
            # Save to file
            with open("config.json", "w") as f:
                json.dump(self.scanner.config, f, indent=4)
            
            messagebox.showinfo("Success", "Configuration saved successfully")
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save configuration: {str(e)}")
    
    def reset_config(self):
        """
        Reset the configuration to defaults
        """
        # Ask for confirmation
        if not messagebox.askyesno("Confirm Reset", "Are you sure you want to reset all settings to default values?"):
            return
        
        try:
            # Reload default config
            self.scanner = VulnerabilityScanner()
            
            # Update UI with default values
            self.config_threads_var.set(self.scanner.config.get("max_threads", 5))
            self.config_delay_var.set(self.scanner.config.get("scan_delay", 0.5))
            self.config_timeout_var.set(self.scanner.config.get("request_timeout", 10))
            
            # Update payload text areas
            self.xss_payloads_text.delete(1.0, tk.END)
            self.xss_payloads_text.insert(tk.END, "\n".join(self.scanner.config.get("xss_payloads", [])))
            
            self.sql_payloads_text.delete(1.0, tk.END)
            self.sql_payloads_text.insert(tk.END, "\n".join(self.scanner.config.get("sql_payloads", [])))
            
            self.csrf_fields_text.delete(1.0, tk.END)
            self.csrf_fields_text.insert(tk.END, "\n".join(self.scanner.config.get("csrf_fields", [])))
            
            messagebox.showinfo("Success", "Configuration reset to defaults")
        
        except Exception as e:
            messagebox.showerror("Error", f"Failed to reset configuration: {str(e)}")
    
    def log(self, message):
        """
        Add a message to the log
        
        Args:
            message: Message to log
        """
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        self.log_text.config(state=tk.NORMAL)
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
    
    def check_queue(self):
        """
        Check the message queue for updates from the scanner
        """
        try:
            while True:
                message = self.queue.get_nowait()
                self.log(message)
        except queue.Empty:
            pass
        
        # Check queue again in 100 ms
        self.root.after(100, self.check_queue)
    
    def on_close(self):
        """
        Handle window close event
        """
        if hasattr(self, 'scan_future') and not self.scan_future.done():
            if not messagebox.askyesno("Confirm Exit", "A scan is in progress. Are you sure you want to quit?"):
                return
            self.scan_future.cancel()
        
        # Stop asyncio thread
        if hasattr(self, 'asyncio_thread'):
            self.asyncio_thread.stop()
        
        self.root.destroy()

def start_gui():
    """
    Start the GUI
    """
    try:
        root = tk.Tk()
        app = ScannerGUI(root)
        root.mainloop()
    except Exception as e:
        logger.error(f"Error starting GUI: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    start_gui()
