import argparse
import asyncio
import json
import logging
import sys
from datetime import datetime
from urllib.parse import urlparse
from scanner.core import VulnerabilityScanner
from scanner.utils import display_time

logger = logging.getLogger(__name__)

class CLIColors:
    """
    ANSI color codes for CLI output
    """
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    
    # Severity colors
    CRITICAL = '\033[41m'  # Red background
    HIGH = '\033[101m'     # Light red background
    MEDIUM = '\033[43m'    # Yellow background
    LOW = '\033[44m'       # Blue background
    INFO = '\033[42m'      # Green background

def severity_color(severity):
    """
    Get the color code for a severity level
    
    Args:
        severity: Severity level
        
    Returns:
        str: Color code
    """
    severity = severity.lower()
    if severity == 'critical':
        return CLIColors.CRITICAL
    elif severity == 'high':
        return CLIColors.HIGH
    elif severity == 'medium':
        return CLIColors.MEDIUM
    elif severity == 'low':
        return CLIColors.LOW
    elif severity == 'info':
        return CLIColors.INFO
    else:
        return CLIColors.ENDC

def print_banner():
    """
    Print the CLI banner
    """
    banner = """
    __      __   _            ____                                
    \\ \\    / /  | |          / ___|                               
     \\ \\  / /_ _| |_ __     / /    ___ __ _ _ __  _ __   ___ _ __ 
      \\ \\/ / _` | | '_ \\   / /|   / __/ _` | '_ \\| '_ \\ / _ \\ '__|
       \\  / (_| | | | | | / /\\ \\ | (_| (_| | | | | | | |  __/ |   
        \\/ \\__,_|_|_| |_| \\____/  \\___\\__,_|_| |_|_| |_|\\___|_|   
                                                       
    Vulnerability Scanner - Advanced Web Security Testing Tool
    """
    print(CLIColors.OKBLUE + banner + CLIColors.ENDC)
    print(CLIColors.HEADER + "=" * 80 + CLIColors.ENDC)
    print()

async def cli_scan(args):
    """
    Run a scan from the command line
    
    Args:
        args: Command line arguments
    """
    print_banner()
    
    print(f"{CLIColors.BOLD}Target:{CLIColors.ENDC} {args.url}")
    print(f"{CLIColors.BOLD}Scan Options:{CLIColors.ENDC}")
    print(f"  - Max Threads: {args.threads}")
    print(f"  - Max Depth: {args.depth}")
    print(f"  - Authenticated: {'Yes' if args.username and args.password else 'No'}")
    print()
    
    print(f"{CLIColors.OKGREEN}[+] Starting scan...{CLIColors.ENDC}")
    
    start_time = datetime.now()
    
    # Initialize the scanner
    scanner = VulnerabilityScanner()
    
    # Update scanner config with CLI args
    scanner.config['max_threads'] = args.threads
    scanner.config['max_depth'] = args.depth
    
    try:
        # Run the scan
        report = await scanner.scan(
            target_url=args.url,
            login_url=args.login_url,
            username=args.username,
            password=args.password,
            max_depth=args.depth
        )
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        # Display scan results
        print()
        print(f"{CLIColors.OKGREEN}[+] Scan completed in {display_time(duration)}{CLIColors.ENDC}")
        print(f"{CLIColors.OKGREEN}[+] Found {len(scanner.vulnerabilities)} vulnerabilities{CLIColors.ENDC}")
        print()
        
        # Display vulnerability summary
        if scanner.vulnerabilities:
            print(f"{CLIColors.BOLD}Vulnerability Summary:{CLIColors.ENDC}")
            for severity in ['Critical', 'High', 'Medium', 'Low', 'Info']:
                count = sum(1 for v in scanner.vulnerabilities if v.get('severity') == severity)
                if count > 0:
                    color = severity_color(severity)
                    print(f"  {color} {severity} {CLIColors.ENDC}: {count}")
            
            print()
            print(f"{CLIColors.BOLD}Top Vulnerabilities:{CLIColors.ENDC}")
            
            # Display top 10 most severe vulnerabilities
            for i, vuln in enumerate(sorted(scanner.vulnerabilities, 
                                          key=lambda v: {'Critical': 5, 'High': 4, 'Medium': 3, 'Low': 2, 'Info': 1}.get(v.get('severity'), 0), 
                                          reverse=True)[:10]):
                severity = vuln.get('severity', 'Low')
                color = severity_color(severity)
                print(f"{i+1}. {color} {severity} {CLIColors.ENDC} - {vuln.get('type')}: {vuln.get('message')}")
                print(f"   URL: {vuln.get('url')}")
            
            print()
            print(f"{CLIColors.BOLD}Generating report...{CLIColors.ENDC}")
            
            # Generate report
            from scanner.report import Report
            report_generator = Report()
            
            # Save report
            if args.output:
                output_path = args.output
                if output_path.endswith('.json'):
                    report_path = report_generator.save_json(report, output_path)
                elif output_path.endswith('.docx'):
                    report_path = report_generator.save_docx(report, output_path, args.website_name)
                else:
                    report_path = report_generator.save_txt(report, output_path)
            else:
                # Save based on format option
                if args.format == 'json':
                    report_path = report_generator.save_json(report)
                elif args.format == 'docx':
                    report_path = report_generator.save_docx(report, website_name=args.website_name or urlparse(args.url).netloc)
                else:
                    report_path = report_generator.save_txt(report)
            
            print(f"{CLIColors.OKGREEN}[+] Report saved to: {report_path}{CLIColors.ENDC}")
        else:
            print(f"{CLIColors.WARNING}[!] No vulnerabilities found.{CLIColors.ENDC}")
    
    except KeyboardInterrupt:
        print(f"\n{CLIColors.WARNING}[!] Scan interrupted by user.{CLIColors.ENDC}")
    except Exception as e:
        print(f"\n{CLIColors.FAIL}[!] Error during scan: {str(e)}{CLIColors.ENDC}")
        logger.error(f"Scan error: {str(e)}", exc_info=True)

def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Web Vulnerability Scanner CLI')
    
    # Main URL can be provided with --url or as a positional argument
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('url_positional', nargs='?', help='URL to scan', default=None)
    group.add_argument('--url', dest='url', help='URL to scan')
    
    parser.add_argument('--threads', type=int, default=5, help='Number of concurrent threads (default: 5)')
    parser.add_argument('--depth', type=int, default=3, help='Crawl depth (default: 3)')
    parser.add_argument('--verbose', action='store_true', help='Verbose output')
    parser.add_argument('--output', help='Output report file path')
    parser.add_argument('--username', help='Username for authenticated scan')
    parser.add_argument('--password', help='Password for authenticated scan')
    parser.add_argument('--login-url', help='Login URL for authenticated scan')
    parser.add_argument('--format', choices=['txt', 'json', 'docx', 'html'], default='txt',
                        help='Output format for the report (default: txt)')
    parser.add_argument('--website-name', help='Website name for the DOCX report title')
    
    args = parser.parse_args()
    
    # Use the positional URL if provided, otherwise use --url
    if args.url_positional:
        args.url = args.url_positional
    
    return args

if __name__ == "__main__":
    args = parse_args()
    
    try:
        asyncio.run(cli_scan(args))
    except KeyboardInterrupt:
        print("\nScan interrupted by user")
        sys.exit(0)
