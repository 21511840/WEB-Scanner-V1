import os
import json
import logging
from datetime import datetime
import asyncio
from threading import Thread

from flask import render_template, request, jsonify, redirect, url_for, flash, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

# These imports are commented out because they're handled differently in register_routes
# from app import app, db
# from models import User, Scan, Vulnerability, Configuration
from scanner.core import VulnerabilityScanner
from scanner.utils import get_timestamp, sort_vulnerabilities

# Set up logging
logger = logging.getLogger(__name__)

# Initialize scanner
scanner = VulnerabilityScanner()

# Create asyncio event loop for scanner
loop = asyncio.new_event_loop()
scan_thread = None

def register_routes(app):
    """Register all routes for the web application."""
    # Import necessary models to avoid circular imports
    from app import db
    from models import User, Scan, Vulnerability, Configuration
    from flask_login import current_user, login_required, login_user, logout_user
    # Context processor to pass common data to all templates
    @app.context_processor
    def inject_common_data():
        return {
            'app_name': 'Web Vulnerability Scanner',
            'current_year': datetime.now().year
        }

    @app.route('/')
    def index():
        """Render the home page."""
        return render_template('index.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Handle user login."""
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            user = User.query.filter_by(username=username).first()
            
            if user and check_password_hash(user.password_hash, password):
                login_user(user)
                flash('Login successful!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid username or password', 'danger')
        
        return render_template('index.html')

    @app.route('/logout')
    @login_required
    def logout():
        """Handle user logout."""
        logout_user()
        flash('You have been logged out', 'info')
        return redirect(url_for('index'))

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        """Handle user registration."""
        if request.method == 'POST':
            username = request.form.get('username')
            email = request.form.get('email')
            password = request.form.get('password')
            
            # Check if username or email already exists
            if User.query.filter_by(username=username).first():
                flash('Username already exists', 'danger')
                return redirect(url_for('index'))
            
            if User.query.filter_by(email=email).first():
                flash('Email already exists', 'danger')
                return redirect(url_for('index'))
            
            # Create new user
            new_user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(password)
            )
            
            db.session.add(new_user)
            db.session.commit()
            
            flash('Registration successful! You can now login.', 'success')
            return redirect(url_for('index'))
        
        return render_template('index.html')

    @app.route('/dashboard')
    @login_required
    def dashboard():
        """Render the dashboard page."""
        # Get user's past scans
        scans = Scan.query.filter_by(user_id=current_user.id).order_by(Scan.started_at.desc()).all()
        
        # Get ongoing scans
        ongoing_scans = Scan.query.filter_by(user_id=current_user.id, status='in_progress').all()
        
        return render_template('dashboard.html', scans=scans, ongoing_scans=ongoing_scans)

    @app.route('/scan', methods=['POST'])
    @login_required
    def start_scan():
        """Start a new vulnerability scan."""
        # Extract scan parameters
        url = request.form.get('url')
        login_url = request.form.get('login_url', '')
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        max_depth = int(request.form.get('max_depth', 3))
        max_pages = int(request.form.get('max_pages', 100))
        
        # Validate URL
        if not url:
            flash('Please enter a URL to scan', 'danger')
            return redirect(url_for('dashboard'))
        
        # Create scan record
        new_scan = Scan(
            target_url=url,
            status='in_progress',
            user_id=current_user.id
        )
        db.session.add(new_scan)
        db.session.commit()
        
        # Start scan in background thread
        def run_scan(scan_id, url, login_url, username, password, max_depth, max_pages):
            asyncio.set_event_loop(loop)
            try:
                # Run scan
                result = loop.run_until_complete(
                    scanner.scan(
                        target_url=url,
                        login_url=login_url,
                        username=username,
                        password=password,
                        max_depth=max_depth,
                        max_pages=max_pages,
                        scan_id=scan_id
                    )
                )
                
                # Update scan status
                with app.app_context():
                    scan = Scan.query.get(scan_id)
                    scan.status = 'completed'
                    scan.completed_at = datetime.now()
                    
                    # Save vulnerabilities
                    for vuln in scanner.vulnerabilities:
                        new_vuln = Vulnerability(
                            scan_id=scan_id,
                            name=vuln.get('type', 'Unknown'),
                            description=vuln.get('message', ''),
                            url=vuln.get('url', ''),
                            severity=vuln.get('severity', 'Low'),
                            type=vuln.get('type', 'Unknown')
                        )
                        
                        # Save details if available
                        if 'details' in vuln:
                            new_vuln.set_details(vuln['details'])
                        
                        db.session.add(new_vuln)
                    
                    db.session.commit()
            except Exception as e:
                logger.error(f"Scan error: {str(e)}", exc_info=True)
                # Update scan status to failed
                with app.app_context():
                    scan = Scan.query.get(scan_id)
                    scan.status = 'failed'
                    scan.completed_at = datetime.now()
                    db.session.commit()
        
        # Start scan in background thread
        global scan_thread
        if scan_thread is not None and scan_thread.is_alive():
            flash('A scan is already in progress. Please wait for it to complete.', 'warning')
            return redirect(url_for('dashboard'))
        
        scan_thread = Thread(
            target=run_scan, 
            args=(new_scan.id, url, login_url, username, password, max_depth, max_pages)
        )
        scan_thread.daemon = True
        scan_thread.start()
        
        flash(f'Scan started for {url}', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/scan/<int:scan_id>/status')
    @login_required
    def scan_status(scan_id):
        """Get the status of a scan."""
        scan = Scan.query.get_or_404(scan_id)
        
        # Ensure user owns this scan
        if scan.user_id != current_user.id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        # Calculate progress based on completed_at
        progress = 100 if scan.status == 'completed' else (
            0 if scan.status == 'failed' else 50  # Simplified progress for in_progress
        )
        
        return jsonify({
            'status': scan.status,
            'progress': progress,
            'started_at': scan.started_at.isoformat(),
            'completed_at': scan.completed_at.isoformat() if scan.completed_at else None,
            'vulnerabilities_count': scan.vulnerabilities.count()
        })

    @app.route('/scan/<int:scan_id>')
    @login_required
    def scan_report(scan_id):
        """Show the report for a completed scan."""
        scan = Scan.query.get_or_404(scan_id)
        
        # Ensure user owns this scan
        if scan.user_id != current_user.id:
            flash('You do not have permission to view this scan', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get vulnerabilities
        vulnerabilities = scan.vulnerabilities.all()
        
        # Sort vulnerabilities by severity
        sorted_vulnerabilities = sorted(
            vulnerabilities,
            key=lambda v: {'Critical': 5, 'High': 4, 'Medium': 3, 'Low': 2, 'Info': 1}.get(v.severity, 0),
            reverse=True
        )
        
        # Group vulnerabilities by type
        vuln_by_type = {}
        for vuln in sorted_vulnerabilities:
            if vuln.type not in vuln_by_type:
                vuln_by_type[vuln.type] = []
            vuln_by_type[vuln.type].append(vuln)
        
        # Vulnerability statistics
        vuln_stats = {
            'Critical': len([v for v in vulnerabilities if v.severity == 'Critical']),
            'High': len([v for v in vulnerabilities if v.severity == 'High']),
            'Medium': len([v for v in vulnerabilities if v.severity == 'Medium']),
            'Low': len([v for v in vulnerabilities if v.severity == 'Low']),
            'Info': len([v for v in vulnerabilities if v.severity == 'Info']),
            'Total': len(vulnerabilities)
        }
        
        return render_template(
            'scan_report.html',
            scan=scan,
            vulnerabilities=sorted_vulnerabilities,
            vuln_by_type=vuln_by_type,
            vuln_stats=vuln_stats
        )

    @app.route('/scan/<int:scan_id>/delete', methods=['POST'])
    @login_required
    def delete_scan(scan_id):
        """Delete a scan and its vulnerabilities."""
        scan = Scan.query.get_or_404(scan_id)
        
        # Ensure user owns this scan
        if scan.user_id != current_user.id:
            flash('You do not have permission to delete this scan', 'danger')
            return redirect(url_for('dashboard'))
        
        # Delete vulnerabilities first
        Vulnerability.query.filter_by(scan_id=scan_id).delete()
        
        # Delete scan
        db.session.delete(scan)
        db.session.commit()
        
        flash('Scan deleted successfully', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/scan/<int:scan_id>/export/<format>')
    @login_required
    def export_scan(scan_id, format):
        """Export a scan report in various formats."""
        scan = Scan.query.get_or_404(scan_id)
        
        # Ensure user owns this scan
        if scan.user_id != current_user.id:
            flash('You do not have permission to export this scan', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get vulnerabilities
        vulnerabilities = scan.vulnerabilities.all()
        
        # Format vulnerabilities for export
        vuln_list = []
        for vuln in vulnerabilities:
            vuln_dict = {
                'severity': vuln.severity,
                'type': vuln.type,
                'url': vuln.url,
                'message': vuln.description,
                'details': vuln.get_details()
            }
            vuln_list.append(vuln_dict)
        
        # Prepare report data
        report_data = {
            'timestamp': scan.started_at.strftime("%Y-%m-%d %H:%M:%S"),
            'target_url': scan.target_url,
            'scan_info': {
                'start_time': scan.started_at,
                'end_time': scan.completed_at,
                'duration': scan.duration(),
                'urls_scanned': len(set([v.url for v in vulnerabilities]))
            },
            'vulnerabilities': sort_vulnerabilities(vuln_list),
            'stats': {
                'total': len(vulnerabilities),
                'by_severity': {
                    'Critical': len([v for v in vulnerabilities if v.severity == 'Critical']),
                    'High': len([v for v in vulnerabilities if v.severity == 'High']),
                    'Medium': len([v for v in vulnerabilities if v.severity == 'Medium']),
                    'Low': len([v for v in vulnerabilities if v.severity == 'Low']),
                    'Info': len([v for v in vulnerabilities if v.severity == 'Info'])
                },
                'by_type': {}
            }
        }
        
        # Count by type
        for vuln in vulnerabilities:
            if vuln.type not in report_data['stats']['by_type']:
                report_data['stats']['by_type'][vuln.type] = 0
            report_data['stats']['by_type'][vuln.type] += 1
        
        # Generate appropriate format
        from scanner.report import Report
        report_generator = Report()
        
        if format == 'json':
            # Create tmp directory if it doesn't exist
            os.makedirs('tmp', exist_ok=True)
            
            # Generate timestamp
            timestamp = get_timestamp()
            
            # Save report to tmp directory
            filepath = f"tmp/scan_report_{scan_id}_{timestamp}.json"
            report_generator.save_json(report_data, filepath)
            
            # Return file
            return jsonify({
                'status': 'success',
                'download_url': f"/download/{os.path.basename(filepath)}"
            })
        
        elif format == 'txt':
            # Create tmp directory if it doesn't exist
            os.makedirs('tmp', exist_ok=True)
            
            # Generate timestamp
            timestamp = get_timestamp()
            
            # Save report to tmp directory
            filepath = f"tmp/scan_report_{scan_id}_{timestamp}.txt"
            report_generator.save_txt(report_data, filepath)
            
            # Return file
            return jsonify({
                'status': 'success',
                'download_url': f"/download/{os.path.basename(filepath)}"
            })
        
        else:
            return jsonify({'error': 'Unsupported export format'}), 400

    @app.route('/download/<filename>')
    @login_required
    def download_file(filename):
        """Download a generated report file."""
        # Ensure file is in tmp directory
        if '/' in filename or '..' in filename:
            return jsonify({'error': 'Invalid filename'}), 400
        
        # Check if file exists
        filepath = os.path.join('tmp', filename)
        if not os.path.exists(filepath):
            return jsonify({'error': 'File not found'}), 404
        
        # Determine content type
        content_type = 'text/plain'
        if filename.endswith('.json'):
            content_type = 'application/json'
        
        # Return file
        with open(filepath, 'r') as f:
            content = f.read()
        
        response = app.response_class(
            response=content,
            status=200,
            mimetype=content_type
        )
        response.headers["Content-Disposition"] = f"attachment; filename={filename}"
        return response

    @app.route('/configuration')
    @login_required
    def configuration():
        """Show and edit configuration."""
        # Only admin users should access this
        if not current_user.username == 'admin':
            flash('You do not have permission to access the configuration', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get configuration
        config = Configuration.query.all()
        
        # Convert to dict
        config_dict = {}
        for c in config:
            try:
                config_dict[c.name] = json.loads(c.value)
            except:
                config_dict[c.name] = c.value
        
        # If empty, load from scanner
        if not config_dict:
            config_dict = scanner.config
        
        return render_template('configuration.html', config=config_dict)

    @app.route('/configuration/save', methods=['POST'])
    @login_required
    def save_configuration():
        """Save configuration changes."""
        # Only admin users should access this
        if not current_user.username == 'admin':
            flash('You do not have permission to access the configuration', 'danger')
            return redirect(url_for('dashboard'))
        
        # Get form data
        config_data = {}
        for key, value in request.form.items():
            # Handle lists (from textareas with newlines)
            if key in ['xss_payloads', 'sql_payloads', 'csrf_fields', 'cmd_payloads']:
                config_data[key] = [line.strip() for line in value.split('\n') if line.strip()]
            # Handle numbers
            elif key in ['scan_delay', 'max_threads', 'request_timeout', 'max_crawl_pages', 'max_depth']:
                try:
                    config_data[key] = float(value) if '.' in value else int(value)
                except:
                    config_data[key] = value
            else:
                config_data[key] = value
        
        # Save configuration
        for name, value in config_data.items():
            Configuration.set_value(name, value)
        
        # Update scanner config
        scanner.config = config_data
        
        flash('Configuration saved successfully', 'success')
        return redirect(url_for('configuration'))

    # Error handlers
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('error.html', error_code=404, error_message="Page not found"), 404

    @app.errorhandler(500)
    def server_error(e):
        return render_template('error.html', error_code=500, error_message="Internal server error"), 500
